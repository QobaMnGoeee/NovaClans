package kz.qoba.NovaEvents.commands;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import kz.qoba.NovaEvents.NovaEvents;
import kz.qoba.NovaEvents.listeners.PlayerListener;
import kz.qoba.NovaEvents.models.EventModel;
import kz.qoba.NovaEvents.utils.ColorUtil;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;

public class AEventsCommand implements CommandExecutor, TabCompleter {
   private final NovaEvents plugin;

   public AEventsCommand(NovaEvents plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("NovaEvents.admin")) {
         sender.sendMessage(this.plugin.getConfigManager().getMessage("no-permission"));
         return true;
      } else if (args.length == 0) {
         this.sendHelp(sender);
         return true;
      } else {
         switch (args[0].toLowerCase()) {
            case "reload": {
               this.plugin.getConfigManager().reload();
               this.plugin.getEventManager().loadEvents();
               this.plugin.getEventManager().startScheduler();
               sender.sendMessage(this.plugin.getConfigManager().getMessage("event-reloaded"));
               break;
            }
            case "list": {
               sender.sendMessage(this.plugin.getConfigManager().getMessage("event-list-header"));
               for (EventModel model : this.plugin.getEventManager().getEvents().values()) {
                  String status = model.getState().name();
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("event-list-entry",
                        Map.of("event_id", model.getId(), "status", status)));
               }
               break;
            }
            case "forcestart": {
               if (args.length < 2) {
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("usage-forcestart"));
                  return true;
               }
               String id = args[1];
               EventModel model = this.findEvent(args[1]);
               if (model == null) {
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("event-not-found", Map.of("event_id", id)));
                  return true;
               }
               if (model.getState() != EventModel.EventState.IDLE) {
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("event-already-active"));
                  return true;
               }
               this.plugin.getEventManager().spawnEvent(model);
               sender.sendMessage(this.plugin.getConfigManager().getMessage("event-started", Map.of("event_id", model.getId())));
               break;
            }
            case "tp": {
               if (!(sender instanceof Player)) {
                  sender.sendMessage(ColorUtil.colorize("&cТек ойыншылар үшін!"));
                  return true;
               }
               Player player = (Player) sender;
               if (args.length < 2) {
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("usage-tp"));
                  return true;
               }
               String id = args[1];
               EventModel model = this.findEvent(args[1]);
               if (model == null) {
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("event-not-found", Map.of("event_id", id)));
                  return true;
               }
               if (!this.plugin.getEventManager().teleportToEvent(player, model)) {
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("event-not-active"));
                  return true;
               }
               sender.sendMessage(this.plugin.getConfigManager().getMessage("event-teleported",
                     Map.of("event_id", model.getId(),
                           "event_name", ColorUtil.colorize(model.getDisplayName()),
                           "x", String.valueOf(model.getActiveData().getSpawnLocation().getBlockX()),
                           "z", String.valueOf(model.getActiveData().getSpawnLocation().getBlockZ()))));
               break;
            }
            case "forcestop": {
               if (args.length < 2) {
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("usage-forcestop"));
                  return true;
               }
               String id = args[1];
               EventModel model = this.findEvent(args[1]);
               if (model == null) {
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("event-not-found", Map.of("event_id", id)));
                  return true;
               }
               if (model.getState() == EventModel.EventState.IDLE) {
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("event-not-active"));
                  return true;
               }
               this.plugin.getEventManager().forceStop(model);
               sender.sendMessage(this.plugin.getConfigManager().getMessage("event-stopped", Map.of("event_id", model.getId())));
               break;
            }
            case "loot": {
               if (!(sender instanceof Player)) {
                  sender.sendMessage(ColorUtil.colorize("&cТек ойыншылар үшін!"));
                  return true;
               }
               Player player = (Player) sender;
               if (args.length < 2) {
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("usage-loot"));
                  return true;
               }
               String id = args[1];
               EventModel model = this.findEvent(args[1]);
               if (model == null) {
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("event-not-found", Map.of("event_id", id)));
                  return true;
               }
               PlayerListener listener = this.getPlayerListener();
               if (listener != null) {
                  listener.openLootGUI(player, model);
               }
               break;
            }
            case "create": {
               if (args.length < 2) {
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("usage-create"));
                  return true;
               }
               String id = args[1];
               if (this.plugin.getEventManager().getEvent(id) != null) {
                  sender.sendMessage(ColorUtil.colorize("&cИвент бұрыннан бар: &e" + id));
                  return true;
               }
               this.plugin.getConfigManager().createEvent(id);
               this.plugin.getEventManager().loadEvents();
               sender.sendMessage(this.plugin.getConfigManager().getMessage("event-created", Map.of("event_id", id)));
               break;
            }
            case "delete": {
               if (args.length < 2) {
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("usage-delete"));
                  return true;
               }
               String id = args[1];
               EventModel model = this.findEvent(args[1]);
               if (model == null) {
                  sender.sendMessage(this.plugin.getConfigManager().getMessage("event-not-found", Map.of("event_id", id)));
                  return true;
               }
               if (model.getState() != EventModel.EventState.IDLE) {
                  this.plugin.getEventManager().forceStop(model);
               }
               this.plugin.getConfigManager().deleteEvent(model.getId());
               this.plugin.getEventManager().loadEvents();
               sender.sendMessage(this.plugin.getConfigManager().getMessage("event-deleted", Map.of("event_id", model.getId())));
               break;
            }
            default:
               this.sendHelp(sender);
         }
         return true;
      }
   }

   private void sendHelp(CommandSender sender) {
      String prefix = this.plugin.getConfigManager().getPrefix();
      sender.sendMessage(ColorUtil.colorize("&8&m-----&r " + prefix + "&aNovaEvents &8&m-----"));
      sender.sendMessage(ColorUtil.colorize("&e/aevents forcestart <id> &7- Ивентті іске қосу"));
      sender.sendMessage(ColorUtil.colorize("&e/aevents forcestop <id> &7- Ивентті тоқтату"));
      sender.sendMessage(ColorUtil.colorize("&e/aevents tp <id> &7- Белсенді ивентке телепорт"));
      sender.sendMessage(ColorUtil.colorize("&e/aevents list &7- Ивенттер тізімі"));
      sender.sendMessage(ColorUtil.colorize("&e/aevents loot <id> &7- Лут редакторы"));
      sender.sendMessage(ColorUtil.colorize("&e/aevents create <id> &7- Ивент жасау"));
      sender.sendMessage(ColorUtil.colorize("&e/aevents delete <id> &7- Ивентті жою"));
      sender.sendMessage(ColorUtil.colorize("&e/aevents reload &7- Қайта жүктеу"));
      sender.sendMessage(ColorUtil.colorize("&8&m---------------------------------"));
   }

   private PlayerListener getPlayerListener() {
      return (PlayerListener) HandlerList.getRegisteredListeners(this.plugin).stream()
            .map(reg -> reg.getListener())
            .filter(l -> l instanceof PlayerListener)
            .findFirst()
            .orElse(null);
   }

   private EventModel findEvent(String input) {
      EventModel direct = this.plugin.getEventManager().getEvent(input);
      if (direct != null) {
         return direct;
      }
      String normalized = ChatColor.stripColor(ColorUtil.colorize(input)).replace(" ", "").toLowerCase(Locale.ROOT);
      for (EventModel model : this.plugin.getEventManager().getEvents().values()) {
         String display = ChatColor.stripColor(ColorUtil.colorize(model.getDisplayName())).replace(" ", "").toLowerCase(Locale.ROOT);
         if (display.equals(normalized)) {
            return model;
         }
      }
      return null;
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      if (!sender.hasPermission("NovaEvents.admin")) return Collections.emptyList();
      if (args.length == 1) {
         List<String> cmds = List.of("forcestart", "forcestop", "tp", "list", "loot", "create", "delete", "reload");
         return cmds.stream().filter(c -> c.startsWith(args[0].toLowerCase())).collect(Collectors.toList());
      }
      if (args.length == 2) {
         String sub = args[0].toLowerCase();
         if (sub.equals("forcestart") || sub.equals("forcestop") || sub.equals("tp") || sub.equals("loot") || sub.equals("delete")) {
            return this.plugin.getEventManager().getEvents().keySet().stream()
                  .filter(id -> id.startsWith(args[1]))
                  .collect(Collectors.toList());
         }
      }
      return Collections.emptyList();
   }
}
