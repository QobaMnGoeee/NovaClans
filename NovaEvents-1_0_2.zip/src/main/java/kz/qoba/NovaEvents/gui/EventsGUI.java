package kz.qoba.NovaEvents.gui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import kz.qoba.NovaEvents.NovaEvents;
import kz.qoba.NovaEvents.models.ActiveEventData;
import kz.qoba.NovaEvents.models.EventMenuItem;
import kz.qoba.NovaEvents.models.EventModel;
import kz.qoba.NovaEvents.models.EventStage;
import kz.qoba.NovaEvents.utils.ColorUtil;
import kz.qoba.NovaEvents.utils.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

public class EventsGUI {
   private final NovaEvents plugin;
   private final Map<Integer, String> slotToEventId = new HashMap();

   public EventsGUI(NovaEvents plugin) {
      this.plugin = plugin;
   }

   public Inventory buildGUI() {
      this.slotToEventId.clear();
      String title = ColorUtil.colorize(this.plugin.getConfigManager().getConfig().getString("gui.title", "&8» &fИвенттер &8«"));
      int size = this.plugin.getConfigManager().getConfig().getInt("gui.size", 45);
      if (size % 9 != 0) {
         size = 45;
      }

      if (size < 9) {
         size = 9;
      }

      if (size > 54) {
         size = 54;
      }

      Inventory inv = Bukkit.createInventory((InventoryHolder)null, size, title);
      ConfigurationSection guiSection = this.plugin.getConfigManager().getConfig().getConfigurationSection("gui");
      if (guiSection != null) {
         for(String key : guiSection.getKeys(false)) {
            if (!key.equalsIgnoreCase("event-slots")) {
               ConfigurationSection section = guiSection.getConfigurationSection(key);
               if (section != null && section.contains("slots") && section.contains("material")) {
                  this.placeDecorativeItem(inv, section);
               }
            }
         }
      }

      ConfigurationSection fillerSection = this.plugin.getConfigManager().getConfig().getConfigurationSection("gui.filler");
      if (fillerSection != null && fillerSection.getBoolean("enabled", false)) {
         Material mat = this.parseMaterial(fillerSection.getString("material"), Material.BLACK_STAINED_GLASS_PANE);
         ItemStack filler = (new ItemBuilder(mat)).name(fillerSection.getString("name", " ")).flags(ItemFlag.HIDE_ATTRIBUTES).build();

         for(int i = 0; i < size; ++i) {
            if (inv.getItem(i) == null) {
               inv.setItem(i, filler);
            }
         }
      }

      for(EventModel model : this.plugin.getEventManager().getEvents().values()) {
         EventMenuItem menuItem = model.getMenuItem();
         if (menuItem != null) {
            int slot = menuItem.getSlot();
            if (slot >= 0 && slot < size) {
               inv.setItem(slot, this.buildEventItem(model, menuItem));
               this.slotToEventId.put(slot, model.getId());
            }
         }
      }

      return inv;
   }

   private void placeDecorativeItem(Inventory inv, ConfigurationSection section) {
      Material mat = this.parseMaterial(section.getString("material"), Material.GRAY_STAINED_GLASS_PANE);
      String name = section.getString("name", " ");
      List<String> lore = section.getStringList("lore");
      ItemStack item = (new ItemBuilder(mat)).name(name).lore(lore).flags(ItemFlag.HIDE_ATTRIBUTES).build();

      for(Object raw : section.getList("slots", List.of())) {
         if (raw instanceof Number number) {
            int slot = number.intValue();
            if (slot >= 0 && slot < inv.getSize()) {
               inv.setItem(slot, item);
            }
         }
      }

   }

   private ItemStack buildEventItem(EventModel model, EventMenuItem menuItem) {
      String displayName = menuItem.getName().replace("{event_name}", ColorUtil.colorize(model.getDisplayName()));
      String nextSpawn = this.plugin.getEventManager().getTimeUntilNextSpawn(model);
      String status = this.getStatusKaz(model.getState());
      String x = "-";
      String z = "-";
      String currentStage = "-";
      String schematic = "-";
      ActiveEventData activeData = model.getActiveData();
      if (activeData != null && model.getState() != EventModel.EventState.IDLE) {
         x = String.valueOf(activeData.getSpawnLocation().getBlockX());
         z = String.valueOf(activeData.getSpawnLocation().getBlockZ());
         currentStage = String.valueOf(activeData.getCurrentStageIndex() + 1);
         EventStage activeStage = model.getStage(activeData.getCurrentStageIndex());
         if (activeStage != null && activeStage.usesSchematic()) {
            schematic = activeStage.getRelativePath();
         } else {
            schematic = "none";
         }
      } else if (model.hasStages()) {
         EventStage firstStage = model.getStage(0);
         if (firstStage != null) {
            schematic = firstStage.usesSchematic() ? firstStage.getRelativePath() : "none";
         }
      } else {
         schematic = "none";
      }

      List<String> lore = new ArrayList();

      for(String line : menuItem.getLore()) {
         lore.add(line.replace("{next_spawn}", nextSpawn).replace("{status}", status).replace("{schematic}", schematic).replace("{stage}", currentStage).replace("{stage_total}", String.valueOf(Math.max(1, model.getStageCount()))).replace("{event_name}", ColorUtil.colorize(model.getDisplayName())).replace("{x}", x).replace("{z}", z));
      }

      if (lore.isEmpty()) {
         lore.add("&7Келесі спавн: &f" + nextSpawn);
         lore.add("&7Күй: &f" + status);
         lore.add("&7Координаттары: &e" + x + ", " + z);
      }

      return (new ItemBuilder(menuItem.getMaterial())).name(displayName).lore(lore).flags(ItemFlag.HIDE_ATTRIBUTES).build();
   }

   private Material parseMaterial(String materialName, Material fallback) {
      try {
         return Material.valueOf(materialName);
      } catch (Exception var4) {
         return fallback;
      }
   }

   private String getStatusKaz(EventModel.EventState state) {
      String var10000;
      switch (state) {
         case IDLE -> var10000 = "&aКүту";
         case ACTIVE -> var10000 = "&eБелсенді";
         case OPEN -> var10000 = "&6Ашық";
         case CLEANING -> var10000 = "&cТазалануда";
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   public EventModel getEventAtSlot(int slot) {
      String eventId = (String)this.slotToEventId.get(slot);
      return eventId == null ? null : this.plugin.getEventManager().getEvent(eventId);
   }
}
