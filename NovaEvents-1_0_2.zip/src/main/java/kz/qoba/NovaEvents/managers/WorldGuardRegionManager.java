package kz.qoba.NovaEvents.managers;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.flags.StateFlag.State;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import java.util.Locale;
import java.util.logging.Level;
import kz.qoba.NovaEvents.NovaEvents;
import org.bukkit.Location;
import org.bukkit.World;

public class WorldGuardRegionManager {
   private final NovaEvents plugin;

   public WorldGuardRegionManager(NovaEvents plugin) {
      this.plugin = plugin;
   }

   public String createEventRegion(String eventId, Location center, int radius) {
      if (center != null && center.getWorld() != null) {
         World world = center.getWorld();
         RegionManager manager = this.getRegionManager(world);
         if (manager == null) {
            this.plugin.getLogger().warning("WorldGuard RegionManager not found for world: " + world.getName());
            return null;
         } else {
            String regionId = this.buildRegionId(eventId, center);
            int minY = Math.max(world.getMinHeight(), this.plugin.getConfigManager().getWorldGuardMinY());
            int maxY = Math.min(world.getMaxHeight() - 1, this.plugin.getConfigManager().getWorldGuardMaxY());
            BlockVector3 min = BlockVector3.at(center.getBlockX() - radius, minY, center.getBlockZ() - radius);
            BlockVector3 max = BlockVector3.at(center.getBlockX() + radius, maxY, center.getBlockZ() + radius);
            ProtectedRegion region = new ProtectedCuboidRegion(regionId, min, max);
            region.setFlag(Flags.PVP, State.ALLOW);
            region.setFlag(Flags.INTERACT, State.ALLOW);
            region.setFlag(Flags.USE, State.ALLOW);
            region.setFlag(Flags.CHEST_ACCESS, State.ALLOW);
            region.setFlag(Flags.BUILD, State.DENY);
            region.setFlag(Flags.BLOCK_BREAK, State.DENY);
            region.setFlag(Flags.BLOCK_PLACE, State.DENY);
            region.setFlag(Flags.CREEPER_EXPLOSION, State.DENY);
            region.setFlag(Flags.TNT, State.DENY);
            region.setPriority(this.plugin.getConfigManager().getConfig().getInt("worldguard.priority", 50));
            manager.addRegion(region);

            try {
               manager.save();
            } catch (Exception e) {
               this.plugin.getLogger().log(Level.WARNING, "Could not save WorldGuard regions after creating " + regionId, e);
            }

            return regionId;
         }
      } else {
         return null;
      }
   }

   public void removeRegion(World world, String regionId) {
      if (world != null && regionId != null && !regionId.isBlank()) {
         RegionManager manager = this.getRegionManager(world);
         if (manager != null) {
            manager.removeRegion(regionId);

            try {
               manager.save();
            } catch (Exception e) {
               this.plugin.getLogger().log(Level.WARNING, "Could not save WorldGuard regions after removing " + regionId, e);
            }

         }
      }
   }

   private RegionManager getRegionManager(World world) {
      RegionContainer container = WorldGuard.getInstance().getPlatform().getRegionContainer();
      return container.get(BukkitAdapter.adapt(world));
   }

   private String buildRegionId(String eventId, Location center) {
      return ("alashevent_" + eventId + "_" + center.getBlockX() + "_" + center.getBlockZ()).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_\\-]", "_");
   }
}
