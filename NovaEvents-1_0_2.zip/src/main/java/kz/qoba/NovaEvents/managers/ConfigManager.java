package kz.qoba.NovaEvents.managers;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import kz.qoba.NovaEvents.NovaEvents;
import kz.qoba.NovaEvents.models.EventMenuItem;
import kz.qoba.NovaEvents.models.EventModel;
import kz.qoba.NovaEvents.models.EventParticleConfig;
import kz.qoba.NovaEvents.models.EventStage;
import kz.qoba.NovaEvents.utils.BossBarUtil;
import kz.qoba.NovaEvents.utils.ColorUtil;
import org.bukkit.Material;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

public class ConfigManager {
   private final NovaEvents plugin;
   private FileConfiguration config;
   private FileConfiguration eventsConfig;
   private File eventsFile;

   public ConfigManager(NovaEvents plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      this.plugin.reloadConfig();
      this.config = this.plugin.getConfig();
      this.eventsFile = new File(this.plugin.getDataFolder(), "events.yml");
      if (!this.eventsFile.exists()) {
         this.plugin.saveResource("events.yml", false);
      }

      this.eventsConfig = YamlConfiguration.loadConfiguration(this.eventsFile);
   }

   public String getMessage(String key) {
      String prefix = this.config.getString("prefix", "&#FBFFBAᴀ &7»&r &f");
      String msg = this.config.getString("messages." + key, "&cMessage not found: " + key);
      return ColorUtil.colorize(prefix + msg);
   }

   public String getMessage(String key, Map<String, String> placeholders) {
      String msg = this.getMessage(key);

      for(Map.Entry<String, String> entry : placeholders.entrySet()) {
         msg = msg.replace("{" + (String)entry.getKey() + "}", (CharSequence)entry.getValue());
      }

      return msg;
   }

   public String getPrefix() {
      return ColorUtil.colorize(this.config.getString("prefix", "&#FBFFBAᴀ &7»&r &f"));
   }

   public String getSpawnWorld() {
      return this.config.getString("spawn-world", "world");
   }

   public int getSpawnInterval() {
      return this.config.getInt("spawn-interval", 20);
   }

   public int getBossbarDuration() {
      return this.config.getInt("bossbar-duration", 300);
   }

   public int getCleanupDelay() {
      return this.config.getInt("cleanup-delay", 240);
   }

   public int getSpawnRadius() {
      return this.config.getInt("spawn-radius", 500);
   }

   public int getSpawnMinRadius() {
      return this.config.getInt("spawn-min-radius", 50);
   }

   public int getSpawnAttempts() {
      return this.config.getInt("spawn-attempts", 80);
   }

   public int getSchematicPasteYOffset() {
      return Math.max(0, this.config.getInt("schematic-paste-y-offset", 3));
   }

   public int getWorldGuardRegionRadius() {
      return Math.max(1, this.config.getInt("worldguard.region-radius", 100));
   }

   public int getWorldGuardMinY() {
      return this.config.getInt("worldguard.min-y", -64);
   }

   public int getWorldGuardMaxY() {
      return this.config.getInt("worldguard.max-y", 320);
   }

   public List<String> getForbiddenSpawnBiomes() {
      return this.config.getStringList("spawn-forbidden-biomes");
   }

   public List<Integer> getGuiEventSlots() {
      return this.parseSlotList(this.config.getList("gui.event-slots"));
   }

   public FileConfiguration getConfig() {
      return this.config;
   }

   public FileConfiguration getEventsConfig() {
      return this.eventsConfig;
   }

   public Map<String, EventModel> loadEvents() {
      Map<String, EventModel> events = new LinkedHashMap();
      ConfigurationSection section = this.eventsConfig.getConfigurationSection("events");
      if (section == null) {
         return events;
      } else {
         List<Integer> defaultSlots = this.getGuiEventSlots();
         int slotIndex = 0;

         for(String id : section.getKeys(false)) {
            ConfigurationSection es = section.getConfigurationSection(id);
            if (es != null) {
               String name = es.getString("name", id);
               String world = es.getString("world", this.getSpawnWorld());
               boolean enabled = es.getBoolean("enabled", true);
               int interval = es.getInt("spawn-interval", this.getSpawnInterval());
               int durationSeconds = es.getInt("duration-seconds", this.getBossbarDuration());
               int maxLootItems = es.getInt("max-loot-items", 12);
               int lootEditorSize = this.normalizeInventorySize(es.getInt("loot-editor-size", 54));
               int particleRadius = Math.max(1, es.getInt("particle-radius", 4));
               int pasteYOffset = Math.max(0, es.getInt("paste-y-offset", this.getSchematicPasteYOffset()));
               BarColor bossBarColor = BossBarUtil.parseColor(es.getString("bossbar-color", "YELLOW"));
               BarStyle bossBarStyle = BossBarUtil.parseStyle(es.getString("bossbar-style", "SOLID"));
               int defaultSlot = slotIndex < defaultSlots.size() ? (Integer)defaultSlots.get(slotIndex) : 22;
               EventMenuItem menuItem = this.loadMenuItem(es.getConfigurationSection("menu-item"), defaultSlot);
               ++slotIndex;
               List<EventStage> stages = this.loadStages(id, es);
               EventModel model = new EventModel(id, name, world, enabled, interval, durationSeconds, maxLootItems, lootEditorSize, particleRadius, pasteYOffset, bossBarColor, bossBarStyle, menuItem, stages);
               model.setParticles(this.loadParticles(es.getList("particles")));
               List<?> lootList = es.getList("loot");
               if (lootList != null) {
                  List<ItemStack> lootItems = new ArrayList();

                  for(Object obj : lootList) {
                     if (obj instanceof ItemStack) {
                        ItemStack itemStack = (ItemStack)obj;
                        lootItems.add(itemStack);
                     }
                  }

                  model.setLoot(lootItems);
               }

               model.setNextSpawnTime(System.currentTimeMillis() + (long)interval * 60L * 1000L);
               events.put(id, model);
            }
         }

         return events;
      }
   }

   private EventMenuItem loadMenuItem(ConfigurationSection section, int defaultSlot) {
      return section == null ? new EventMenuItem(Material.BLAZE_POWDER, "&e{event_name}", List.of("&7Келесі спавн: &f{next_spawn}", "&7Күй: &f{status}", "&7Координаттары: &e{x}, {z}"), defaultSlot) : EventMenuItem.fromSection(section, defaultSlot);
   }

   private List<EventStage> loadStages(String eventId, ConfigurationSection eventSection) {
      List<EventStage> stages = new ArrayList();
      ConfigurationSection stagesSection = eventSection.getConfigurationSection("stages");
      if (stagesSection != null) {
         for(String stageKey : stagesSection.getKeys(false)) {
            ConfigurationSection stageSection = stagesSection.getConfigurationSection(stageKey);
            if (stageSection != null) {
               String folder = stageSection.getString("folder", eventId + "/" + stageKey);
               String schematic = stageSection.getString("schematic", stageKey + ".schem");
               boolean useSchematic = !EventStage.isSchematicDisabled(schematic);
               if (stageSection.contains("use-schematic")) {
                  useSchematic = stageSection.getBoolean("use-schematic") && useSchematic;
               }

               if (!useSchematic && !EventStage.isSchematicDisabled(schematic)) {
                  this.plugin.getLogger().warning("Stage " + eventId + "/" + stageKey + " has use-schematic: false but schematic is set to '" + schematic + "'. Set use-schematic: true or schematic: none");
               }

               int duration = stageSection.getInt("duration-seconds", eventSection.getInt("duration-seconds", this.getBossbarDuration()));
               int offsetX = stageSection.getInt("shulker-offset.x", 0);
               int offsetY = stageSection.getInt("shulker-offset.y", 0);
               int offsetZ = stageSection.getInt("shulker-offset.z", 0);
               List<EventParticleConfig> stageParticles = this.loadParticles(stageSection.getList("particles"));
               stages.add(new EventStage(folder, schematic, useSchematic, duration, offsetX, offsetY, offsetZ, stageParticles));
            }
         }
      }

      stages.sort(Comparator.comparingInt((stage) -> this.extractTrailingNumber(stage.getFolder())));
      return stages;
   }

   private List<EventParticleConfig> loadParticles(List<?> rawList) {
      List<EventParticleConfig> particles = new ArrayList();
      if (rawList == null) {
         return particles;
      } else {
         for(Object entry : rawList) {
            if (entry instanceof ConfigurationSection) {
               ConfigurationSection section = (ConfigurationSection)entry;
               particles.add(EventParticleConfig.fromSection(section));
            } else if (entry instanceof Map) {
               Map<?, ?> map = (Map)entry;
               YamlConfiguration temp = new YamlConfiguration();

               for(Map.Entry<?, ?> mapEntry : map.entrySet()) {
                  if (mapEntry.getKey() != null) {
                     temp.set(String.valueOf(mapEntry.getKey()), mapEntry.getValue());
                  }
               }

               particles.add(EventParticleConfig.fromSection(temp));
            }
         }

         return particles;
      }
   }

   private void saveParticles(String path, List<EventParticleConfig> particles) {
      if (particles != null && !particles.isEmpty()) {
         List<Map<String, Object>> serialized = new ArrayList();

         for(EventParticleConfig particle : particles) {
            Map<String, Object> map = new LinkedHashMap();
            map.put("type", particle.getTypeName());
            map.put("count", particle.getCount());
            map.put("speed", particle.getSpeed());
            map.put("spread", particle.getSpread());
            map.put("interval-ticks", particle.getIntervalTicks());
            map.put("offset-y", particle.getOffsetY());
            map.put("enabled", particle.isEnabled());
            if (particle.getDustColor() != null && !particle.getDustColor().isBlank()) {
               map.put("dust-color", particle.getDustColor());
               map.put("dust-size", particle.getDustSize());
            }

            serialized.add(map);
         }

         this.eventsConfig.set(path, serialized);
      } else {
         this.eventsConfig.set(path, (Object)null);
      }
   }

   private void saveMenuItem(String path, EventMenuItem menuItem) {
      if (menuItem != null) {
         this.eventsConfig.set(path + ".material", menuItem.getMaterial().name());
         this.eventsConfig.set(path + ".name", menuItem.getName());
         this.eventsConfig.set(path + ".lore", menuItem.getLore());
         this.eventsConfig.set(path + ".slot", menuItem.getSlot());
      }
   }

   private int extractTrailingNumber(String text) {
      if (text == null) {
         return Integer.MAX_VALUE;
      } else {
         String digits = text.replaceAll(".*?(\\d+)$", "$1");
         if (digits.matches("\\d+")) {
            try {
               return Integer.parseInt(digits);
            } catch (NumberFormatException var4) {
            }
         }

         return Integer.MAX_VALUE;
      }
   }

   public int normalizeInventorySize(int size) {
      if (size < 9) {
         return 9;
      } else if (size > 54) {
         return 54;
      } else {
         int rows = (int)Math.ceil((double)size / (double)9.0F);
         return rows * 9;
      }
   }

   private List<Integer> parseSlotList(List<?> raw) {
      List<Integer> slots = new ArrayList();
      if (raw == null) {
         slots.add(22);
         return slots;
      } else {
         for(Object o : raw) {
            if (o instanceof Number) {
               Number number = (Number)o;
               slots.add(number.intValue());
            }
         }

         if (slots.isEmpty()) {
            slots.add(22);
         }

         return slots;
      }
   }

   public void saveEvent(EventModel model) {
      String path = "events." + model.getId();
      this.eventsConfig.set(path + ".name", model.getDisplayName());
      this.eventsConfig.set(path + ".world", model.getWorld());
      this.eventsConfig.set(path + ".enabled", model.isEnabled());
      this.eventsConfig.set(path + ".spawn-interval", model.getSpawnInterval());
      this.eventsConfig.set(path + ".duration-seconds", model.getDurationSeconds());
      this.eventsConfig.set(path + ".max-loot-items", model.getMaxLootItems());
      this.eventsConfig.set(path + ".loot-editor-size", model.getLootEditorSize());
      this.eventsConfig.set(path + ".particle-radius", model.getParticleRadius());
      this.eventsConfig.set(path + ".paste-y-offset", model.getPasteYOffset());
      this.eventsConfig.set(path + ".bossbar-color", model.getBossBarColor().name());
      this.eventsConfig.set(path + ".bossbar-style", model.getBossBarStyle().name());
      this.eventsConfig.set(path + ".schematic", (Object)null);
      this.saveParticles(path + ".particles", model.getParticles());
      this.saveMenuItem(path + ".menu-item", model.getMenuItem());
      this.eventsConfig.set(path + ".stages", (Object)null);

      for(int i = 0; i < model.getStages().size(); ++i) {
         EventStage stage = (EventStage)model.getStages().get(i);
         String stagePath = path + ".stages.stage" + (i + 1);
         this.eventsConfig.set(stagePath + ".folder", stage.getFolder());
         if (stage.usesSchematic()) {
            this.eventsConfig.set(stagePath + ".schematic", stage.getSchematicFile());
            this.eventsConfig.set(stagePath + ".use-schematic", true);
         } else {
            this.eventsConfig.set(stagePath + ".schematic", "none");
            this.eventsConfig.set(stagePath + ".use-schematic", false);
         }

         this.eventsConfig.set(stagePath + ".duration-seconds", stage.getDurationSeconds());
         this.eventsConfig.set(stagePath + ".shulker-offset.x", stage.getShulkerOffsetX());
         this.eventsConfig.set(stagePath + ".shulker-offset.y", stage.getShulkerOffsetY());
         this.eventsConfig.set(stagePath + ".shulker-offset.z", stage.getShulkerOffsetZ());
         this.saveParticles(stagePath + ".particles", stage.getParticles());
      }

      this.eventsConfig.set(path + ".loot", model.getLoot());
      this.saveEventsConfig();
   }

   public void saveEventLoot(EventModel model) {
      this.eventsConfig.set("events." + model.getId() + ".loot", model.getLoot());
      this.saveEventsConfig();
   }

   public void deleteEvent(String id) {
      this.eventsConfig.set("events." + id, (Object)null);
      this.saveEventsConfig();
   }

   public void createEvent(String id) {
      String path = "events." + id;
      List<Integer> slots = this.getGuiEventSlots();
      int slot = slots.isEmpty() ? 22 : (Integer)slots.get(Math.min(slots.size() - 1, 0));
      this.eventsConfig.set(path + ".name", "&fИвент " + id);
      this.eventsConfig.set(path + ".world", this.getSpawnWorld());
      this.eventsConfig.set(path + ".enabled", true);
      this.eventsConfig.set(path + ".spawn-interval", this.getSpawnInterval());
      this.eventsConfig.set(path + ".duration-seconds", 120);
      this.eventsConfig.set(path + ".max-loot-items", 12);
      this.eventsConfig.set(path + ".loot-editor-size", 54);
      this.eventsConfig.set(path + ".particle-radius", 4);
      this.eventsConfig.set(path + ".bossbar-color", "YELLOW");
      this.eventsConfig.set(path + ".bossbar-style", "SOLID");
      this.eventsConfig.set(path + ".menu-item.material", "BLAZE_POWDER");
      this.eventsConfig.set(path + ".menu-item.name", "&e{event_name}");
      this.eventsConfig.set(path + ".menu-item.lore", List.of("&7Келесі спавн: &f{next_spawn}", "&7Күй: &f{status}", "&7Координаттары: &e{x}, {z}"));
      this.eventsConfig.set(path + ".menu-item.slot", slot);
      this.eventsConfig.set(path + ".loot", new ArrayList());
      this.eventsConfig.set(path + ".particles", List.of(Map.of("type", "PORTAL", "count", 6, "speed", 0.04, "spread", (double)2.0F, "interval-ticks", 10, "enabled", true), Map.of("type", "END_ROD", "count", 3, "speed", 0.02, "spread", (double)1.5F, "interval-ticks", 8, "enabled", true)));
      String stagePath = path + ".stages.stage1";
      this.eventsConfig.set(stagePath + ".folder", id + "/stage1");
      this.eventsConfig.set(stagePath + ".schematic", "stage1.schem");
      this.eventsConfig.set(stagePath + ".use-schematic", true);
      this.eventsConfig.set(stagePath + ".duration-seconds", 120);
      this.eventsConfig.set(stagePath + ".shulker-offset.x", 0);
      this.eventsConfig.set(stagePath + ".shulker-offset.y", 0);
      this.eventsConfig.set(stagePath + ".shulker-offset.z", 0);
      this.saveEventsConfig();
   }

   private void saveEventsConfig() {
      try {
         this.eventsConfig.save(this.eventsFile);
      } catch (IOException e) {
         this.plugin.getLogger().log(Level.SEVERE, "Could not save events.yml", e);
      }

   }
}
