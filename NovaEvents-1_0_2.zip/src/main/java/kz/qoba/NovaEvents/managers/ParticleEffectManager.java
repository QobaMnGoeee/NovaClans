package kz.qoba.NovaEvents.managers;

import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.CuboidRegion;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import kz.qoba.NovaEvents.NovaEvents;
import kz.qoba.NovaEvents.models.ActiveEventData;
import kz.qoba.NovaEvents.models.EventModel;
import kz.qoba.NovaEvents.models.EventParticleConfig;
import kz.qoba.NovaEvents.models.EventStage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.scheduler.BukkitRunnable;

public class ParticleEffectManager {
   private final NovaEvents plugin;
   private final Random random = new Random();
   private final Set<String> warnedParticleTypes = new HashSet();

   public ParticleEffectManager(NovaEvents plugin) {
      this.plugin = plugin;
   }

   public void startForStage(final EventModel model, final ActiveEventData data, EventStage stage) {
      this.stop(data);
      final List<EventParticleConfig> configs = this.resolveParticles(model, stage);
      if (!configs.isEmpty()) {
         int taskId = (new BukkitRunnable() {
            private int tick;

            public void run() {
               if (model.getState() != EventModel.EventState.IDLE && model.getActiveData() == data) {
                  World world = data.getSpawnLocation().getWorld();
                  CuboidRegion region = ParticleEffectManager.this.resolveParticleRegion(model, data);
                  if (world != null && region != null) {
                     ++this.tick;

                     for(EventParticleConfig config : configs) {
                        if (config.isEnabled() && this.tick % config.getIntervalTicks() == 0) {
                           ParticleEffectManager.this.spawnEffect(world, region, config);
                        }
                     }

                  }
               } else {
                  this.cancel();
               }
            }
         }).runTaskTimer(this.plugin, 0L, 1L).getTaskId();
         data.setParticleTaskId(taskId);
      }
   }

   public CuboidRegion resolveParticleRegion(EventModel model, ActiveEventData data) {
      if (data.getSavedRegion() != null) {
         return data.getSavedRegion();
      } else if (data.getParticleRegion() != null) {
         return data.getParticleRegion();
      } else {
         Location center = data.getShulkerLocation() != null ? data.getShulkerLocation() : data.getSpawnLocation();
         return this.createRegionAround(center, model.getParticleRadius());
      }
   }

   public CuboidRegion createRegionAround(Location center, int radius) {
      int r = Math.max(1, radius);
      BlockVector3 min = BlockVector3.at(center.getBlockX() - r, center.getBlockY() - r, center.getBlockZ() - r);
      BlockVector3 max = BlockVector3.at(center.getBlockX() + r, center.getBlockY() + r, center.getBlockZ() + r);
      return new CuboidRegion(min, max);
   }

   public void stop(ActiveEventData data) {
      if (data != null) {
         if (data.getParticleTaskId() != -1) {
            Bukkit.getScheduler().cancelTask(data.getParticleTaskId());
            data.setParticleTaskId(-1);
         }

      }
   }

   public List<EventParticleConfig> resolveParticles(EventModel model, EventStage stage) {
      List<EventParticleConfig> stageParticles = stage == null ? List.of() : stage.getParticles();
      return stageParticles != null && !stageParticles.isEmpty() ? this.filterEnabled(stageParticles) : this.filterEnabled(model.getParticles());
   }

   private List<EventParticleConfig> filterEnabled(List<EventParticleConfig> configs) {
      List<EventParticleConfig> enabled = new ArrayList();

      for(EventParticleConfig config : configs) {
         if (config.isEnabled()) {
            enabled.add(config);
         }
      }

      return enabled;
   }

   private void spawnEffect(World world, CuboidRegion region, EventParticleConfig config) {
      Particle particle = config.resolveParticle();
      if (particle == null) {
         if (this.warnedParticleTypes.add(config.getTypeName().toUpperCase())) {
            this.plugin.getLogger().log(Level.WARNING, "Unknown particle type: " + config.getTypeName());
         }

      } else {
         Location location = this.randomSurfaceLocation(world, region, config);
         Object particleData = config.resolveParticleData(particle);
         double spread = 0.15;
         if (particleData != null) {
            world.spawnParticle(particle, location, config.getCount(), spread, spread, spread, config.getSpeed(), particleData);
         } else {
            world.spawnParticle(particle, location, config.getCount(), spread, spread, spread, config.getSpeed());
         }

      }
   }

   private Location randomSurfaceLocation(World world, CuboidRegion region, EventParticleConfig config) {
      BlockVector3 min = region.getMinimumPoint();
      BlockVector3 max = region.getMaximumPoint();
      int spreadBlocks = (int)Math.ceil(config.getSpread());
      int minX = min.x() - spreadBlocks;
      int maxX = max.x() + spreadBlocks;
      int minY = min.y() + config.getOffsetY();
      int maxY = max.y() + config.getOffsetY();
      int minZ = min.z() - spreadBlocks;
      int maxZ = max.z() + spreadBlocks;
      if (minY > maxY) {
         int tmp = minY;
         minY = maxY;
         maxY = tmp;
      }

      double y;
      double z;
      double x;
      switch (this.random.nextInt(6)) {
         case 0:
            x = (double)minX + (double)0.5F;
            y = (double)minY + this.random.nextDouble() * (double)Math.max(1, maxY - minY + 1);
            z = (double)minZ + this.random.nextDouble() * (double)Math.max(1, maxZ - minZ + 1);
            break;
         case 1:
            x = (double)maxX + (double)0.5F;
            y = (double)minY + this.random.nextDouble() * (double)Math.max(1, maxY - minY + 1);
            z = (double)minZ + this.random.nextDouble() * (double)Math.max(1, maxZ - minZ + 1);
            break;
         case 2:
            x = (double)minX + this.random.nextDouble() * (double)Math.max(1, maxX - minX + 1);
            y = (double)minY + (double)0.5F;
            z = (double)minZ + this.random.nextDouble() * (double)Math.max(1, maxZ - minZ + 1);
            break;
         case 3:
            x = (double)minX + this.random.nextDouble() * (double)Math.max(1, maxX - minX + 1);
            y = (double)maxY + (double)0.5F;
            z = (double)minZ + this.random.nextDouble() * (double)Math.max(1, maxZ - minZ + 1);
            break;
         case 4:
            x = (double)minX + this.random.nextDouble() * (double)Math.max(1, maxX - minX + 1);
            y = (double)minY + this.random.nextDouble() * (double)Math.max(1, maxY - minY + 1);
            z = (double)minZ + (double)0.5F;
            break;
         default:
            x = (double)minX + this.random.nextDouble() * (double)Math.max(1, maxX - minX + 1);
            y = (double)minY + this.random.nextDouble() * (double)Math.max(1, maxY - minY + 1);
            z = (double)maxZ + (double)0.5F;
      }

      return new Location(world, x, y, z);
   }
}
