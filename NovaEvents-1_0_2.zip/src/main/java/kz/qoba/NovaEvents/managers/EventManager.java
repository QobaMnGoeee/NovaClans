package kz.qoba.NovaEvents.managers;

import com.sk89q.worldedit.WorldEditException;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.CuboidRegion;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import kz.qoba.NovaEvents.NovaEvents;
import kz.qoba.NovaEvents.models.ActiveEventData;
import kz.qoba.NovaEvents.models.EventModel;
import kz.qoba.NovaEvents.models.EventStage;
import kz.qoba.NovaEvents.utils.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.ShulkerBox;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

public class EventManager {
   private final NovaEvents plugin;
   private final Map<String, EventModel> events = new LinkedHashMap();
   private int schedulerTaskId = -1;
   private final Set<UUID> shulkerViewers = ConcurrentHashMap.newKeySet();

   public EventManager(NovaEvents plugin) {
      this.plugin = plugin;
      this.loadEvents();
   }

   public void loadEvents() {
      this.events.clear();
      this.events.putAll(this.plugin.getConfigManager().loadEvents());
   }

   public Map<String, EventModel> getEvents() {
      return this.events;
   }

   public EventModel getEvent(String id) {
      return (EventModel)this.events.get(id);
   }

   public void startScheduler() {
      if (this.schedulerTaskId != -1) {
         Bukkit.getScheduler().cancelTask(this.schedulerTaskId);
      }

      this.schedulerTaskId = (new BukkitRunnable() {
         public void run() {
            long now = System.currentTimeMillis();

            for(EventModel model : EventManager.this.events.values()) {
               if (model.isEnabled() && model.getState() == EventModel.EventState.IDLE && now >= model.getNextSpawnTime()) {
                  EventManager.this.spawnEvent(model);
               }
            }

         }
      }).runTaskTimer(this.plugin, 20L, 20L).getTaskId();
   }

   public void stopAll() {
      if (this.schedulerTaskId != -1) {
         Bukkit.getScheduler().cancelTask(this.schedulerTaskId);
      }

      for(EventModel model : this.events.values()) {
         if (model.getState() != EventModel.EventState.IDLE) {
            this.forceStop(model);
         }
      }

   }

   public void spawnEvent(EventModel model) {
      if (model.getState() != EventModel.EventState.IDLE) {
         this.plugin.getLogger().warning("Tried to spawn active event: " + model.getId());
      } else {
         World world = Bukkit.getWorld(model.getWorld());
         if (world == null) {
            this.plugin.getLogger().warning("World not found: " + model.getWorld());
         } else {
            for(EventStage stage : model.getStages()) {
               if (stage != null && stage.usesSchematic() && !this.plugin.getSchematicManager().schematicExists(stage.getRelativePath())) {
                  Bukkit.getConsoleSender().sendMessage(this.plugin.getConfigManager().getMessage("schematic-not-found", Map.of("file", stage.getRelativePath())));
                  return;
               }
            }

            Location spawnLoc = this.findRandomLocation(world);
            if (spawnLoc == null) {
               this.plugin.getLogger().warning("Could not find valid spawn location for event: " + model.getId());
            } else {
               int initialDuration = model.hasStages() ? model.getStage(0).getDurationSeconds() : model.getDurationSeconds();
               BossBar bossBar = this.createBossBar(model);

               for(Player p : Bukkit.getOnlinePlayers()) {
                  bossBar.addPlayer(p);
               }

               ActiveEventData data = new ActiveEventData(spawnLoc, bossBar, (long)initialDuration, this.plugin.getConfigManager().getWorldGuardRegionRadius());
               data.setCurrentStageIndex(0);
               model.setState(EventModel.EventState.ACTIVE);
               model.setActiveData(data);
               this.broadcastEventSpawn(model, spawnLoc);
               if (!model.hasStages()) {
                  this.applyStageWithoutSchematic(model, data, 0, this.createRuntimeStage(model, model.getDurationSeconds()));
               } else {
                  this.beginStage(model, data, 0);
               }

            }
         }
      }
   }

   private BossBar createBossBar(EventModel model) {
      return Bukkit.createBossBar("", model.getBossBarColor(), model.getBossBarStyle(), new BarFlag[0]);
   }

   private EventStage createRuntimeStage(EventModel model, int durationSeconds) {
      return new EventStage(model.getId() + "/runtime", "none", false, durationSeconds, 0, 0, 0, List.of());
   }

   private void broadcastEventSpawn(EventModel model, Location spawnLoc) {
      Map<String, String> placeholders = new HashMap();
      placeholders.put("event_name", ColorUtil.colorize(model.getDisplayName()));
      placeholders.put("world", spawnLoc.getWorld().getName());
      placeholders.put("x", String.valueOf(spawnLoc.getBlockX()));
      placeholders.put("y", String.valueOf(spawnLoc.getBlockY()));
      placeholders.put("z", String.valueOf(spawnLoc.getBlockZ()));
      String spawnMsg = this.plugin.getConfigManager().getMessage("event-spawn", placeholders);
      Sound startSound = this.getConfiguredStartSound();
      float startVolume = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.event-start.volume", (double)1.0F);
      float startPitch = (float)this.plugin.getConfigManager().getConfig().getDouble("sounds.event-start.pitch", (double)1.0F);

      for(Player p : Bukkit.getOnlinePlayers()) {
         p.sendMessage(spawnMsg);
         p.playSound(p.getLocation(), startSound, startVolume, startPitch);
      }

   }

   private void beginStage(EventModel model, ActiveEventData data, int stageIndex) {
      EventStage stage = model.getStage(stageIndex);
      if (stage == null) {
         this.unlockShulker(model, data);
      } else {
         data.setCurrentStageIndex(stageIndex);
         data.setCurrentStageSecondsLeft(stage.getDurationSeconds());
         data.setBossDuration((long)stage.getDurationSeconds());
         if (!stage.usesSchematic()) {
            Logger var6 = this.plugin.getLogger();
            String var7 = model.getId();
            var6.info("Event " + var7 + " stage " + (stageIndex + 1) + ": no schematic (schematic: none or use-schematic: false)");
            Bukkit.getScheduler().runTask(this.plugin, () -> this.applyStageWithoutSchematic(model, data, stageIndex, stage));
         } else {
            String schematicPath = stage.getRelativePath();
            Logger var10000 = this.plugin.getLogger();
            String var10001 = model.getId();
            var10000.info("Event " + var10001 + " stage " + (stageIndex + 1) + ": loading schematic " + schematicPath);
            Bukkit.getScheduler().runTaskAsynchronously(this.plugin, () -> {
               try {
                  Clipboard clipboard = this.plugin.getSchematicManager().loadSchematic(schematicPath);
                  Bukkit.getScheduler().runTask(this.plugin, () -> this.applyStage(model, data, stageIndex, stage, clipboard));
               } catch (IOException e) {
                  this.plugin.getLogger().log(Level.SEVERE, "Error loading stage schematic: " + schematicPath, e);
                  this.forceStop(model);
               }

            });
         }
      }
   }

   private void applyStage(EventModel model, ActiveEventData data, int stageIndex, EventStage stage, Clipboard clipboard) {
      if (model.getActiveData() == data && model.getState() != EventModel.EventState.IDLE) {
         World world = Bukkit.getWorld(model.getWorld());
         if (world == null) {
            this.forceStop(model);
         } else {
            try {
               this.removeEventShulker(model, data);
               if (data.isSchematicPlaced() || !data.getPlacedBlockPositions().isEmpty()) {
                  this.plugin.getSchematicManager().cleanupSchematic(world, data);
                  data.setSavedRegion((CuboidRegion)null);
                  data.setSchematicPlaced(false);
               }

               Location anchor = data.getSpawnLocation();
               SchematicManager.Placement placement = this.plugin.getSchematicManager().calculatePlacement(clipboard, anchor, world, model.getPasteYOffset());
               CuboidRegion region = placement.getWorldRegion();
               this.ensureChunksLoaded(world, region);
               BlockVector3 centerWorld = placement.getCenterWorld();
               Logger var10000 = this.plugin.getLogger();
               String var10001 = model.getId();
               var10000.info("Pasting schematic for " + var10001 + " stage " + (stageIndex + 1) + " | shulker center " + centerWorld.x() + ", " + centerWorld.y() + ", " + centerWorld.z() + " | paste min " + placement.getPasteMin().x() + ", " + placement.getPasteMin().y() + ", " + placement.getPasteMin().z() + " | volume " + region.getVolume());
               this.plugin.getSchematicManager().prepareAndPaste(clipboard, world, placement, data);
               data.setSavedRegion(region);
               data.setParticleRegion(region);
               data.setSchematicOrigin(placement.getPasteMin());
               data.setSchematicCenterWorld(centerWorld);
               data.setSchematicPlaced(true);
               this.finishStageSetup(model, data, stageIndex, stage);
            } catch (WorldEditException e) {
               this.plugin.getLogger().log(Level.SEVERE, "WorldEdit error pasting stage schematic", e);
               this.forceStop(model);
            }

         }
      }
   }

   private void applyStageWithoutSchematic(EventModel model, ActiveEventData data, int stageIndex, EventStage stage) {
      if (model.getActiveData() == data && model.getState() != EventModel.EventState.IDLE) {
         World world = Bukkit.getWorld(model.getWorld());
         if (world == null) {
            this.forceStop(model);
         } else {
            this.removeEventShulker(model, data);
            if (data.isSchematicPlaced() || !data.getPlacedBlockPositions().isEmpty()) {
               this.plugin.getSchematicManager().cleanupSchematic(world, data);
               data.setSavedRegion((CuboidRegion)null);
               data.setSchematicPlaced(false);
            }

            Location center = data.getSpawnLocation();
            data.setParticleRegion(this.plugin.getParticleEffectManager().createRegionAround(center, model.getParticleRadius()));
            this.finishStageSetup(model, data, stageIndex, stage);
         }
      }
   }

   private void finishStageSetup(EventModel model, ActiveEventData data, int stageIndex, EventStage stage) {
      World world = Bukkit.getWorld(model.getWorld());
      if (world == null) {
         this.forceStop(model);
      } else {
         if (data.getWorldGuardRegionId() == null) {
            Location wgCenter = data.getSchematicCenterWorld() != null ? new Location(world, (double)data.getSchematicCenterWorld().x() + (double)0.5F, (double)data.getSchematicCenterWorld().y(), (double)data.getSchematicCenterWorld().z() + (double)0.5F) : data.getSpawnLocation();
            String regionId = this.plugin.getWorldGuardRegionManager().createEventRegion(model.getId(), wgCenter, data.getProtectedRadius());
            data.setWorldGuardRegionId(regionId);
         }

         Location shulkerBase;
         if (data.getSchematicCenterWorld() != null) {
            BlockVector3 center = data.getSchematicCenterWorld();
            shulkerBase = new Location(world, (double)center.x(), (double)center.y(), (double)center.z());
         } else {
            shulkerBase = data.getSpawnLocation();
         }

         Location shulkerLoc = new Location(world, (double)(shulkerBase.getBlockX() + stage.getShulkerOffsetX()), (double)(shulkerBase.getBlockY() + stage.getShulkerOffsetY()), (double)(shulkerBase.getBlockZ() + stage.getShulkerOffsetZ()));
         data.setShulkerLocation(shulkerLoc);
         this.placeEventShulkerBlock(model, data, this.buildLockedShulkerName(model));
         this.plugin.getHologramManager().spawnHologram(model, data);
         this.plugin.getParticleEffectManager().startForStage(model, data, stage);
         this.startBossBarCountdown(model, data, stageIndex, stage.getDurationSeconds());
      }
   }

   private void startBossBarCountdown(final EventModel model, final ActiveEventData data, final int stageIndex, final int totalSeconds) {
      if (data.getBossBarTaskId() != -1) {
         Bukkit.getScheduler().cancelTask(data.getBossBarTaskId());
      }

      data.getBossBar().setProgress((double)1.0F);
      data.getBossBar().setTitle(this.buildBossBarTitle(model, data.getSpawnLocation(), totalSeconds, stageIndex));
      int taskId = (new BukkitRunnable() {
         int secondsLeft = totalSeconds;

         public void run() {
            if (model.getState() == EventModel.EventState.ACTIVE && model.getActiveData() == data && data.getCurrentStageIndex() == stageIndex) {
               --this.secondsLeft;
               data.setCurrentStageSecondsLeft(this.secondsLeft);
               data.getBossBar().setProgress(Math.max((double)0.0F, (double)this.secondsLeft / (double)Math.max(1, totalSeconds)));
               data.getBossBar().setTitle(EventManager.this.buildBossBarTitle(model, data.getSpawnLocation(), this.secondsLeft, stageIndex));
               if (this.secondsLeft <= 0) {
                  this.cancel();
                  if (stageIndex + 1 < model.getStageCount()) {
                     EventManager.this.beginStage(model, data, stageIndex + 1);
                  } else {
                     EventManager.this.unlockShulker(model, data);
                  }
               }

            } else {
               this.cancel();
            }
         }
      }).runTaskTimer(this.plugin, 20L, 20L).getTaskId();
      data.setBossBarTaskId(taskId);
   }

   private void unlockShulker(final EventModel model, ActiveEventData data) {
      model.setState(EventModel.EventState.OPEN);
      data.setShulkerUnlocked(true);
      data.getBossBar().removeAll();
      this.updateShulkerBlockName(model, data, this.buildUnlockedShulkerName(model));
      this.plugin.getHologramManager().updateHologram(model, data);
      String msg = this.plugin.getConfigManager().getMessage("event-end", Map.of("event_name", ColorUtil.colorize(model.getDisplayName())));

      for(Player p : Bukkit.getOnlinePlayers()) {
         p.sendMessage(msg);
         p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.5F, 1.0F);
      }

      int cleanupDelay = this.plugin.getConfigManager().getCleanupDelay();
      int taskId = (new BukkitRunnable() {
         public void run() {
            EventManager.this.cleanupEvent(model);
         }
      }).runTaskLater(this.plugin, (long)cleanupDelay * 20L).getTaskId();
      data.setCleanupTaskId(taskId);
   }

   public void cleanupEvent(EventModel model) {
      model.setState(EventModel.EventState.CLEANING);
      ActiveEventData data = model.getActiveData();
      if (data == null) {
         this.resetEvent(model);
      } else {
         this.closeAllShulkerViewers(data);
         this.removeEventShulker(model, data);
         World world = Bukkit.getWorld(model.getWorld());
         if (world != null) {
            this.plugin.getHologramManager().removeHologram(data, world);
            this.plugin.getSchematicManager().cleanupSchematic(world, data);
            data.setSchematicPlaced(false);
            this.plugin.getWorldGuardRegionManager().removeRegion(world, data.getWorldGuardRegionId());
         }

         String msg = this.plugin.getConfigManager().getMessage("event-cleanup", Map.of("event_name", ColorUtil.colorize(model.getDisplayName())));

         for(Player p : Bukkit.getOnlinePlayers()) {
            p.sendMessage(msg);
         }

         this.resetEvent(model);
      }
   }

   private void closeAllShulkerViewers(ActiveEventData data) {
      for(Player p : Bukkit.getOnlinePlayers()) {
         if (this.shulkerViewers.contains(p.getUniqueId())) {
            p.closeInventory();
         }
      }

      this.shulkerViewers.clear();
   }

   private void resetEvent(EventModel model) {
      ActiveEventData data = model.getActiveData();
      if (data != null) {
         if (data.getBossBarTaskId() != -1) {
            Bukkit.getScheduler().cancelTask(data.getBossBarTaskId());
         }

         if (data.getCleanupTaskId() != -1) {
            Bukkit.getScheduler().cancelTask(data.getCleanupTaskId());
         }

         if (data.getLootPopulateTaskId() != -1) {
            Bukkit.getScheduler().cancelTask(data.getLootPopulateTaskId());
         }

         this.plugin.getParticleEffectManager().stop(data);
         data.getBossBar().removeAll();
      }

      model.setActiveData((ActiveEventData)null);
      model.setState(EventModel.EventState.IDLE);
      model.setNextSpawnTime(System.currentTimeMillis() + (long)model.getSpawnInterval() * 60L * 1000L);
   }

   public void forceStop(EventModel model) {
      if (model.getState() != EventModel.EventState.IDLE) {
         ActiveEventData data = model.getActiveData();
         if (data != null) {
            if (data.getBossBarTaskId() != -1) {
               Bukkit.getScheduler().cancelTask(data.getBossBarTaskId());
            }

            if (data.getCleanupTaskId() != -1) {
               Bukkit.getScheduler().cancelTask(data.getCleanupTaskId());
            }

            if (data.getLootPopulateTaskId() != -1) {
               Bukkit.getScheduler().cancelTask(data.getLootPopulateTaskId());
            }

            this.plugin.getParticleEffectManager().stop(data);
            this.closeAllShulkerViewers(data);
            this.removeEventShulker(model, data);
            World world = Bukkit.getWorld(model.getWorld());
            if (world != null) {
               this.plugin.getHologramManager().removeHologram(data, world);
               this.plugin.getSchematicManager().cleanupSchematic(world, data);
               data.setSchematicPlaced(false);
               this.plugin.getWorldGuardRegionManager().removeRegion(world, data.getWorldGuardRegionId());
            }

            data.getBossBar().removeAll();
         }

         model.setActiveData((ActiveEventData)null);
         model.setState(EventModel.EventState.IDLE);
         model.setNextSpawnTime(System.currentTimeMillis() + (long)model.getSpawnInterval() * 60L * 1000L);
      }
   }

   public boolean openShulkerForPlayer(Player player, EventModel model) {
      ActiveEventData data = model.getActiveData();
      if (data != null && data.isShulkerUnlocked()) {
         if (data.isShulkerOpened() && (Boolean)data.getPlayerHasLooted().getOrDefault(player.getUniqueId(), false)) {
            return false;
         } else {
            if (!data.isShulkerOpened()) {
               data.setShulkerOpened(true);
               this.updateShulkerOpenedAppearance(model, data);
            }

            if (!data.isLootGenerated() && !data.isLootPopulating()) {
               this.populateShulkerLoot(model, data);
            }

            Inventory inv = this.getShulkerInventory(model, data);
            if (inv == null) {
               return false;
            } else {
               this.shulkerViewers.add(player.getUniqueId());
               player.openInventory(inv);
               return true;
            }
         }
      } else {
         player.sendMessage(this.plugin.getConfigManager().getMessage("shulker-locked"));
         return false;
      }
   }

   private Inventory getShulkerInventory(EventModel model, ActiveEventData data) {
      if (data.getLootInventory() != null) {
         return data.getLootInventory();
      } else {
         ShulkerBox shulkerBox = this.getShulkerBox(data);
         if (shulkerBox == null) {
            return null;
         } else {
            data.setLootInventory(shulkerBox.getInventory());
            return data.getLootInventory();
         }
      }
   }

   private void populateShulkerLoot(final EventModel model, final ActiveEventData data) {
      final Inventory shulkerInv = this.getShulkerInventory(model, data);
      if (shulkerInv == null) {
         data.setLootGenerated(true);
      } else {
         List<ItemStack> configuredLoot = model.getLoot();
         if (configuredLoot != null && !configuredLoot.isEmpty()) {
            shulkerInv.clear();
            int maxItems = Math.max(1, model.getMaxLootItems());
            int slotCount = shulkerInv.getSize();
            final List<Integer> slots = new ArrayList();

            for(int i = 0; i < slotCount; ++i) {
               slots.add(i);
            }

            Collections.shuffle(slots);
            final List<ItemStack> available = new ArrayList(configuredLoot);
            Collections.shuffle(available);
            final int toPlace = Math.min(maxItems, Math.min(27, Math.min(available.size(), slots.size())));
            if (toPlace <= 0) {
               data.setLootGenerated(true);
            } else {
               data.setLootPopulating(true);
               int taskId = (new BukkitRunnable() {
                  int index = 0;

                  public void run() {
                     if (model.getState() != EventModel.EventState.IDLE && model.getActiveData() == data) {
                        if (this.index >= toPlace) {
                           data.setLootPopulating(false);
                           data.setLootGenerated(true);
                           data.setLootPopulateTaskId(-1);
                           EventManager.this.updateShulkerBoxState(data);
                           this.cancel();
                        } else {
                           shulkerInv.setItem((Integer)slots.get(this.index), ((ItemStack)available.get(this.index)).clone());
                           ++this.index;
                        }
                     } else {
                        data.setLootPopulating(false);
                        data.setLootPopulateTaskId(-1);
                        this.cancel();
                     }
                  }
               }).runTaskTimer(this.plugin, 0L, 6L).getTaskId();
               data.setLootPopulateTaskId(taskId);
            }
         } else {
            data.setLootGenerated(true);
         }
      }
   }

   private void placeEventShulkerBlock(EventModel model, ActiveEventData data, String customName) {
      Location shulkerLocation = data.getShulkerLocation();
      if (shulkerLocation != null && shulkerLocation.getWorld() != null) {
         Block block = shulkerLocation.getBlock();
         block.setType(Material.SHULKER_BOX, false);
         BlockState var7 = block.getState();
         if (var7 instanceof ShulkerBox) {
            ShulkerBox shulkerBox = (ShulkerBox)var7;
            shulkerBox.getInventory().clear();
            shulkerBox.setCustomName(customName);
            shulkerBox.update(true, false);
            data.setLootInventory(shulkerBox.getInventory());
         }

      }
   }

   private void updateShulkerBlockName(EventModel model, ActiveEventData data, String customName) {
      ShulkerBox shulkerBox = this.getShulkerBox(data);
      if (shulkerBox != null) {
         shulkerBox.setCustomName(customName);
         shulkerBox.update(true, false);
         data.setLootInventory(shulkerBox.getInventory());
      }
   }

   private void updateShulkerBoxState(ActiveEventData data) {
      ShulkerBox shulkerBox = this.getShulkerBox(data);
      if (shulkerBox != null) {
         shulkerBox.update(true, false);
         data.setLootInventory(shulkerBox.getInventory());
      }

   }

   private ShulkerBox getShulkerBox(ActiveEventData data) {
      if (data != null && data.getShulkerLocation() != null && data.getShulkerLocation().getWorld() != null) {
         Block block = data.getShulkerLocation().getBlock();
         BlockState var4 = block.getState();
         if (var4 instanceof ShulkerBox) {
            ShulkerBox shulkerBox = (ShulkerBox)var4;
            return shulkerBox;
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   private void removeEventShulker(EventModel model, ActiveEventData data) {
      data.setLootInventory((Inventory)null);
      Location shulkerLocation = data.getShulkerLocation();
      if (shulkerLocation != null && shulkerLocation.getWorld() != null) {
         Block block = shulkerLocation.getBlock();
         if (block.getType() == Material.SHULKER_BOX) {
            block.setType(Material.AIR, false);
         }

      }
   }

   public void registerShulkerViewer(UUID uuid) {
      this.shulkerViewers.add(uuid);
   }

   public void unregisterShulkerViewer(UUID uuid) {
      this.shulkerViewers.remove(uuid);
   }

   public boolean isShulkerViewer(UUID uuid) {
      return this.shulkerViewers.contains(uuid);
   }

   public EventModel getEventByShulkerBlock(Block block) {
      if (block != null && block.getType() == Material.SHULKER_BOX) {
         for(EventModel model : this.events.values()) {
            ActiveEventData data = model.getActiveData();
            if (data != null && data.getShulkerLocation() != null && block.getWorld().getUID().equals(data.getShulkerLocation().getWorld().getUID()) && block.getX() == data.getShulkerLocation().getBlockX() && block.getY() == data.getShulkerLocation().getBlockY() && block.getZ() == data.getShulkerLocation().getBlockZ()) {
               return model;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public EventModel getProtectedEventAt(Location location) {
      if (location != null && location.getWorld() != null) {
         for(EventModel model : this.events.values()) {
            ActiveEventData data = model.getActiveData();
            if (data != null && data.isInProtectedRadius(location)) {
               return model;
            }
         }

         return null;
      } else {
         return null;
      }
   }

   public boolean canModifyProtectedZone(Player player, Location location) {
      EventModel model = this.getProtectedEventAt(location);
      if (model == null) {
         return true;
      } else {
         return player.hasPermission("NovaEvents.admin") || player.isOp();
      }
   }

   public boolean teleportToEvent(Player player, EventModel model) {
      if (model != null && model.getActiveData() != null && model.getState() != EventModel.EventState.IDLE) {
         Location base = model.getActiveData().getSpawnLocation().clone().add((double)0.5F, (double)1.0F, (double)0.5F);
         Location target = new Location(base.getWorld(), base.getX(), base.getY(), base.getZ(), player.getLocation().getYaw(), player.getLocation().getPitch());
         player.teleport(target);
         return true;
      } else {
         return false;
      }
   }

   private void ensureChunksLoaded(World world, CuboidRegion region) {
      BlockVector3 min = region.getMinimumPoint();
      BlockVector3 max = region.getMaximumPoint();
      int minChunkX = min.x() >> 4;
      int maxChunkX = max.x() >> 4;
      int minChunkZ = min.z() >> 4;
      int maxChunkZ = max.z() >> 4;

      for(int cx = minChunkX; cx <= maxChunkX; ++cx) {
         for(int cz = minChunkZ; cz <= maxChunkZ; ++cz) {
            world.getChunkAt(cx, cz).load(true);
         }
      }

   }

   private Location findRandomLocation(World world) {
      int radius = this.plugin.getConfigManager().getSpawnRadius();
      int minRadius = this.plugin.getConfigManager().getSpawnMinRadius();
      int attempts = this.plugin.getConfigManager().getSpawnAttempts();
      Random random = new Random();

      for(int attempt = 0; attempt < attempts; ++attempt) {
         double angle = random.nextDouble() * (double)2.0F * Math.PI;
         double dist = (double)minRadius + random.nextDouble() * (double)Math.max(1, radius - minRadius);
         int x = (int)(Math.cos(angle) * dist);
         int z = (int)(Math.sin(angle) * dist);
         int groundY = world.getHighestBlockYAt(x, z);
         int y = groundY + 1;
         if (y > world.getMinHeight() && y < world.getMaxHeight() - 10 && !this.isForbiddenSpawnPoint(world, x, groundY, z)) {
            return new Location(world, (double)x, (double)y, (double)z);
         }
      }

      return null;
   }

   private boolean isForbiddenSpawnPoint(World world, int x, int y, int z) {
      Material surface = world.getBlockAt(x, y, z).getType();
      if (surface != Material.WATER && surface != Material.KELP && surface != Material.KELP_PLANT && surface != Material.SEAGRASS && surface != Material.TALL_SEAGRASS) {
         String biome = world.getBiome(x, y, z).getKey().getKey().toUpperCase(Locale.ROOT);

         for(String forbidden : this.plugin.getConfigManager().getForbiddenSpawnBiomes()) {
            String check = forbidden.toUpperCase(Locale.ROOT);
            if (biome.equals(check) || biome.contains(check)) {
               return true;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   private String buildBossBarTitle(EventModel model, Location location, int secondsLeft, int stageIndex) {
      return ColorUtil.colorize(this.plugin.getConfigManager().getConfig().getString("messages.bossbar-title", "&e{event_name} &7| &6{x}, {z} &7| &f{time}").replace("{event_name}", ColorUtil.colorize(model.getDisplayName())).replace("{x}", String.valueOf(location.getBlockX())).replace("{z}", String.valueOf(location.getBlockZ())).replace("{time}", formatTime(secondsLeft)).replace("{stage}", String.valueOf(stageIndex + 1)).replace("{stage_total}", String.valueOf(Math.max(1, model.getStageCount()))));
   }

   private String buildLockedShulkerName(EventModel model) {
      return ColorUtil.colorize(this.plugin.getConfigManager().getConfig().getString("messages.shulker-locked-name", "&c\ud83d\udd12 " + model.getDisplayName() + "&f"));
   }

   private String buildUnlockedShulkerName(EventModel model) {
      return ColorUtil.colorize(this.plugin.getConfigManager().getConfig().getString("messages.shulker-unlocked-name", "&a\ud83d\udd13 " + model.getDisplayName() + "&f"));
   }

   private String buildOpenedShulkerName(EventModel model) {
      return ColorUtil.colorize(this.plugin.getConfigManager().getConfig().getString("messages.shulker-opened-name", "&a\ud83d\udd13 " + model.getDisplayName() + "&7 (ашық)"));
   }

   private void updateShulkerOpenedAppearance(EventModel model, ActiveEventData data) {
      this.updateShulkerBlockName(model, data, this.buildOpenedShulkerName(model));
   }

   private Sound getConfiguredStartSound() {
      String raw = this.plugin.getConfigManager().getConfig().getString("sounds.event-start.sound", "ENTITY_PLAYER_LEVELUP");

      try {
         return Sound.valueOf(raw.toUpperCase(Locale.ROOT));
      } catch (Exception var3) {
         return Sound.ENTITY_PLAYER_LEVELUP;
      }
   }

   public static String formatTime(int totalSeconds) {
      if (totalSeconds <= 0) {
         return "0с";
      } else {
         int hours = totalSeconds / 3600;
         int minutes = totalSeconds % 3600 / 60;
         int seconds = totalSeconds % 60;
         if (hours > 0) {
            return hours + "с " + minutes + "м " + seconds + "с";
         } else {
            return minutes > 0 ? minutes + "м " + seconds + "с" : seconds + "с";
         }
      }
   }

   public String getTimeUntilNextSpawn(EventModel model) {
      if (model.getState() != EventModel.EventState.IDLE) {
         return "Белсенді";
      } else {
         long diff = model.getNextSpawnTime() - System.currentTimeMillis();
         return diff <= 0L ? "Жақын арада..." : formatTime((int)(diff / 1000L));
      }
   }
}
