package kz.qoba.NovaEvents.managers;

import kz.qoba.NovaEvents.NovaEvents;
import kz.qoba.NovaEvents.models.ActiveEventData;
import kz.qoba.NovaEvents.models.EventModel;
import kz.qoba.NovaEvents.utils.ColorUtil;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class HologramManager {

    private final NovaEvents plugin;
    private static final double BASE_HEIGHT = 2.0;
    private static final double LINE_GAP = 0.25;

    public HologramManager(NovaEvents plugin) {
        this.plugin = plugin;
    }

    public void spawnHologram(EventModel model, ActiveEventData data) {
        Location base = data.getShulkerLocation();
        if (base == null || base.getWorld() == null) return;

        World world = base.getWorld();

        removeHologram(data, world);

        List<UUID> ids = new ArrayList<>();
        String[] lines = buildLines(model, data);

        for (int i = 0; i < lines.length; i++) {
            double y = base.getY() + BASE_HEIGHT + (lines.length - 1 - i) * LINE_GAP;
            Location loc = new Location(world, base.getX() + 0.5, y, base.getZ() + 0.5);
            ArmorStand stand = spawnStand(world, loc, lines[i]);
            ids.add(stand.getUniqueId());
        }

        data.setHologramIds(ids);
        startUpdateTask(model, data);
    }

    public void updateHologram(EventModel model, ActiveEventData data) {
        if (data.getHologramIds() == null || data.getHologramIds().isEmpty()) return;
        Location base = data.getShulkerLocation();
        if (base == null || base.getWorld() == null) return;

        World world = base.getWorld();
        String[] lines = buildLines(model, data);

        List<UUID> ids = data.getHologramIds();
        for (int i = 0; i < Math.min(ids.size(), lines.length); i++) {
            org.bukkit.entity.Entity entity = plugin.getServer().getEntity(ids.get(i));
            if (entity instanceof ArmorStand stand) {
                stand.setCustomName(ColorUtil.colorize(lines[i]));
            }
        }
    }

    public void removeHologram(ActiveEventData data, World world) {
        if (data == null || data.getHologramIds() == null) return;
        for (UUID id : data.getHologramIds()) {
            org.bukkit.entity.Entity entity = plugin.getServer().getEntity(id);
            if (entity != null) entity.remove();
        }
        data.getHologramIds().clear();

        if (data.getHologramTaskId() != -1) {
            plugin.getServer().getScheduler().cancelTask(data.getHologramTaskId());
            data.setHologramTaskId(-1);
        }
    }

    private String[] buildLines(EventModel model, ActiveEventData data) {
        String name = model.getDisplayName();

        boolean unlocked = data.isShulkerUnlocked();
        String status = unlocked ? "&aАшық!" : "&cЖабық";

        String time;
        if (unlocked) {
            time = "&eАшық";
        } else {
            int secondsLeft = data.getCurrentStageSecondsLeft();
            time = "&e" + EventManager.formatTime(secondsLeft);
        }

        return new String[]{name, status, time};
    }

    private ArmorStand spawnStand(World world, Location loc, String name) {
        ArmorStand stand = (ArmorStand) world.spawnEntity(loc, EntityType.ARMOR_STAND);
        stand.setVisible(false);
        stand.setGravity(false);
        stand.setCanPickupItems(false);
        stand.setCustomNameVisible(true);
        stand.setCustomName(ColorUtil.colorize(name));
        stand.setInvulnerable(true);
        stand.setSmall(true);
        stand.setPersistent(false);
        stand.getScoreboardTags().add("nova_events_hologram");
        return stand;
    }

    private void startUpdateTask(EventModel model, ActiveEventData data) {
        if (data.getHologramTaskId() != -1) {
            plugin.getServer().getScheduler().cancelTask(data.getHologramTaskId());
        }
        int taskId = new BukkitRunnable() {
            @Override
            public void run() {
                if (model.getState() == EventModel.EventState.IDLE
                        || model.getActiveData() != data
                        || data.getHologramIds() == null
                        || data.getHologramIds().isEmpty()) {
                    cancel();
                    return;
                }
                updateHologram(model, data);
            }
        }.runTaskTimer(plugin, 20L, 20L).getTaskId();
        data.setHologramTaskId(taskId);
    }
}
