package kz.qoba.NovaEvents.models;

import java.util.Locale;
import org.bukkit.Color;
import org.bukkit.Particle;
import org.bukkit.configuration.ConfigurationSection;

public class EventParticleConfig {
   private final String typeName;
   private final int count;
   private final double speed;
   private final double spread;
   private final int intervalTicks;
   private final int offsetY;
   private final boolean enabled;
   private final String dustColor;
   private final float dustSize;

   public EventParticleConfig(String typeName, int count, double speed, double spread, int intervalTicks, int offsetY, boolean enabled, String dustColor, float dustSize) {
      this.typeName = typeName;
      this.count = Math.max(1, count);
      this.speed = speed;
      this.spread = Math.max((double)0.0F, spread);
      this.intervalTicks = Math.max(1, intervalTicks);
      this.offsetY = offsetY;
      this.enabled = enabled;
      this.dustColor = dustColor;
      this.dustSize = dustSize <= 0.0F ? 1.0F : dustSize;
   }

   public static EventParticleConfig fromSection(ConfigurationSection section) {
      String type = section.getString("type", "FLAME");
      int count = section.getInt("count", 3);
      double speed = section.getDouble("speed", 0.02);
      double spread = section.getDouble("spread", (double)1.5F);
      int intervalTicks = section.getInt("interval-ticks", section.getInt("interval", 10));
      int offsetY = section.getInt("offset-y", 0);
      boolean enabled = section.getBoolean("enabled", true);
      String dustColor = section.getString("dust-color", section.getString("color"));
      float dustSize = (float)section.getDouble("dust-size", (double)1.0F);
      return new EventParticleConfig(type, count, speed, spread, intervalTicks, offsetY, enabled, dustColor, dustSize);
   }

   public String getTypeName() {
      return this.typeName;
   }

   public int getCount() {
      return this.count;
   }

   public double getSpeed() {
      return this.speed;
   }

   public double getSpread() {
      return this.spread;
   }

   public int getIntervalTicks() {
      return this.intervalTicks;
   }

   public int getOffsetY() {
      return this.offsetY;
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public String getDustColor() {
      return this.dustColor;
   }

   public float getDustSize() {
      return this.dustSize;
   }

   public Particle resolveParticle() {
      if (this.typeName != null && !this.typeName.isBlank()) {
         try {
            return Particle.valueOf(this.typeName.trim().toUpperCase(Locale.ROOT));
         } catch (IllegalArgumentException var2) {
            return null;
         }
      } else {
         return null;
      }
   }

   public Object resolveParticleData(Particle particle) {
      if (particle != null && this.dustColor != null && !this.dustColor.isBlank()) {
         if (particle != Particle.DUST && particle != Particle.DUST_COLOR_TRANSITION) {
            return null;
         } else {
            Color color = parseColor(this.dustColor);
            return color == null ? null : new Particle.DustOptions(color, this.dustSize);
         }
      } else {
         return null;
      }
   }

   private static Color parseColor(String raw) {
      String value = raw.trim();
      if (value.startsWith("#")) {
         value = value.substring(1);
      }

      try {
         if (value.length() == 6) {
            int rgb = Integer.parseInt(value, 16);
            return Color.fromRGB(rgb >> 16 & 255, rgb >> 8 & 255, rgb & 255);
         }
      } catch (NumberFormatException var3) {
      }

      return null;
   }
}
