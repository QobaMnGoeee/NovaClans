package kz.qoba.NovaEvents.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class EventStage {
   private final String folder;
   private final String schematicFile;
   private final boolean useSchematic;
   private final int durationSeconds;
   private final int shulkerOffsetX;
   private final int shulkerOffsetY;
   private final int shulkerOffsetZ;
   private final List<EventParticleConfig> particles;

   public EventStage(String folder, String schematicFile, boolean useSchematic, int durationSeconds, int shulkerOffsetX, int shulkerOffsetY, int shulkerOffsetZ, List<EventParticleConfig> particles) {
      this.folder = folder;
      this.schematicFile = schematicFile;
      this.useSchematic = useSchematic;
      this.durationSeconds = durationSeconds;
      this.shulkerOffsetX = shulkerOffsetX;
      this.shulkerOffsetY = shulkerOffsetY;
      this.shulkerOffsetZ = shulkerOffsetZ;
      this.particles = particles == null ? new ArrayList() : new ArrayList(particles);
   }

   public static boolean isSchematicDisabled(String schematic) {
      if (schematic == null) {
         return true;
      } else {
         String value = schematic.trim().toLowerCase(Locale.ROOT);
         return value.isEmpty() || value.equals("none") || value.equals("false") || value.equals("off");
      }
   }

   public String getFolder() {
      return this.folder;
   }

   public String getSchematicFile() {
      return this.schematicFile;
   }

   public boolean usesSchematic() {
      return this.useSchematic;
   }

   public String getRelativePath() {
      return this.folder != null && !this.folder.isBlank() ? this.folder + "/" + this.schematicFile : this.schematicFile;
   }

   public int getDurationSeconds() {
      return this.durationSeconds;
   }

   public int getShulkerOffsetX() {
      return this.shulkerOffsetX;
   }

   public int getShulkerOffsetY() {
      return this.shulkerOffsetY;
   }

   public int getShulkerOffsetZ() {
      return this.shulkerOffsetZ;
   }

   public List<EventParticleConfig> getParticles() {
      return this.particles;
   }
}
