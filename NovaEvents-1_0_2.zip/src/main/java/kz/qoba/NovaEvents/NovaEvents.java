package kz.qoba.NovaEvents;

import kz.qoba.NovaEvents.commands.AEventsCommand;
import kz.qoba.NovaEvents.commands.EventsCommand;
import kz.qoba.NovaEvents.listeners.PlayerListener;
import kz.qoba.NovaEvents.managers.ConfigManager;
import kz.qoba.NovaEvents.managers.EventManager;
import kz.qoba.NovaEvents.managers.HologramManager;
import kz.qoba.NovaEvents.managers.ParticleEffectManager;
import kz.qoba.NovaEvents.managers.SchematicManager;
import kz.qoba.NovaEvents.managers.WorldGuardRegionManager;
import org.bukkit.plugin.java.JavaPlugin;

public class NovaEvents extends JavaPlugin {
   private static NovaEvents instance;
   private ConfigManager configManager;
   private EventManager eventManager;
   private HologramManager hologramManager;
   private SchematicManager schematicManager;
   private ParticleEffectManager particleEffectManager;
   private WorldGuardRegionManager worldGuardRegionManager;

   public void onEnable() {
      instance = this;
      this.saveDefaultConfig();
      this.configManager = new ConfigManager(this);
      this.schematicManager = new SchematicManager(this);
      this.particleEffectManager = new ParticleEffectManager(this);
      this.worldGuardRegionManager = new WorldGuardRegionManager(this);
      this.hologramManager = new HologramManager(this);
      this.eventManager = new EventManager(this);
      AEventsCommand aEventsCommand = new AEventsCommand(this);
      this.getCommand("aevents").setExecutor(aEventsCommand);
      this.getCommand("aevents").setTabCompleter(aEventsCommand);
      this.getCommand("events").setExecutor(new EventsCommand(this));
      this.getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
      this.eventManager.startScheduler();
      this.getLogger().info("NovaEvents v" + this.getDescription().getVersion() + " іске қосылды! (Автор: QobaMn)");
   }

   public void onDisable() {
      if (this.eventManager != null) {
         this.eventManager.stopAll();
      }
      this.getLogger().info("NovaEvents өшірілді.");
   }

   public static NovaEvents getInstance() {
      return instance;
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }

   public EventManager getEventManager() {
      return this.eventManager;
   }

   public HologramManager getHologramManager() {
      return this.hologramManager;
   }

   public SchematicManager getSchematicManager() {
      return this.schematicManager;
   }

   public ParticleEffectManager getParticleEffectManager() {
      return this.particleEffectManager;
   }

   public WorldGuardRegionManager getWorldGuardRegionManager() {
      return this.worldGuardRegionManager;
   }
}
