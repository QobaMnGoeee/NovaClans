package kz.qoba.NovaEvents.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarFlag;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;

public class BossBarUtil {
   private static final Map<UUID, BossBar> PLAYER_BARS = new HashMap();
   private static BossBar globalBar;

   public static void create(Player player, String title, BarColor color, BarStyle style, double progress) {
      remove(player);
      BossBar bossBar = Bukkit.createBossBar(title, color, style, new BarFlag[0]);
      bossBar.setProgress(clamp(progress));
      bossBar.addPlayer(player);
      bossBar.setVisible(true);
      PLAYER_BARS.put(player.getUniqueId(), bossBar);
   }

   public static void createGlobal(String title, BarColor color, BarStyle style, double progress) {
      removeGlobal();
      globalBar = Bukkit.createBossBar(title, color, style, new BarFlag[0]);
      globalBar.setProgress(clamp(progress));
      globalBar.setVisible(true);

      for(Player player : Bukkit.getOnlinePlayers()) {
         globalBar.addPlayer(player);
      }

   }

   public static void setGlobalTitle(String title) {
      if (globalBar != null) {
         globalBar.setTitle(title);
      }
   }

   public static void setGlobalProgress(double progress) {
      if (globalBar != null) {
         globalBar.setProgress(clamp(progress));
      }
   }

   public static void addPlayerToGlobal(Player player) {
      if (globalBar != null) {
         globalBar.addPlayer(player);
      }
   }

   public static void removeGlobal() {
      if (globalBar != null) {
         globalBar.removeAll();
         globalBar = null;
      }
   }

   public static void setTitle(Player player, String title) {
      BossBar bossBar = (BossBar)PLAYER_BARS.get(player.getUniqueId());
      if (bossBar != null) {
         bossBar.setTitle(title);
      }
   }

   public static void setProgress(Player player, double progress) {
      BossBar bossBar = (BossBar)PLAYER_BARS.get(player.getUniqueId());
      if (bossBar != null) {
         bossBar.setProgress(clamp(progress));
      }
   }

   public static void setColor(Player player, BarColor color) {
      BossBar bossBar = (BossBar)PLAYER_BARS.get(player.getUniqueId());
      if (bossBar != null) {
         bossBar.setColor(color);
      }
   }

   public static void remove(Player player) {
      BossBar bossBar = (BossBar)PLAYER_BARS.remove(player.getUniqueId());
      if (bossBar != null) {
         bossBar.removeAll();
      }
   }

   public static void removeAll() {
      for(BossBar bossBar : PLAYER_BARS.values()) {
         bossBar.removeAll();
      }

      PLAYER_BARS.clear();
      removeGlobal();
   }

   public static BossBar get(Player player) {
      return (BossBar)PLAYER_BARS.get(player.getUniqueId());
   }

   public static boolean exists(Player player) {
      return PLAYER_BARS.containsKey(player.getUniqueId());
   }

   public static BarColor parseColor(String input) {
      if (input == null) {
         return BarColor.WHITE;
      } else {
         try {
            return BarColor.valueOf(input.toUpperCase());
         } catch (IllegalArgumentException var2) {
            return BarColor.WHITE;
         }
      }
   }

   public static BarStyle parseStyle(String input) {
      if (input == null) {
         return BarStyle.SOLID;
      } else {
         try {
            return BarStyle.valueOf(input.toUpperCase());
         } catch (IllegalArgumentException var2) {
            return BarStyle.SOLID;
         }
      }
   }

   private static double clamp(double value) {
      return Math.max((double)0.0F, Math.min((double)1.0F, value));
   }
}
