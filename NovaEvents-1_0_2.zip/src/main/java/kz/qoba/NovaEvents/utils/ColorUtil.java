package kz.qoba.NovaEvents.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.md_5.bungee.api.ChatColor;

public class ColorUtil {
   private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
   private static final Pattern AMPERSAND_PATTERN = Pattern.compile("&([0-9a-fk-orA-FK-OR])");

   public static String colorize(String text) {
      if (text == null) {
         return "";
      } else {
         Matcher hexMatcher = HEX_PATTERN.matcher(text);
         StringBuffer sb = new StringBuffer();

         while(hexMatcher.find()) {
            String hex = hexMatcher.group(1);
            hexMatcher.appendReplacement(sb, ChatColor.of("#" + hex).toString());
         }

         hexMatcher.appendTail(sb);
         text = sb.toString();
         text = ChatColor.translateAlternateColorCodes('&', text);
         return text;
      }
   }

   public static String strip(String text) {
      return text == null ? "" : ChatColor.stripColor(colorize(text));
   }
}
