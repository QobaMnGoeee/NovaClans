package kz.nova.clans.managers;

import kz.nova.clans.NovaClans;
import kz.nova.clans.data.ClanData;
import kz.nova.clans.data.ClanMember;
import kz.nova.clans.data.ClanRole;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class MenuManager {
    private final NovaClans plugin;
    private YamlConfiguration clanMenuConfig;
    private YamlConfiguration storageMenuConfig;
    private YamlConfiguration membersMenuConfig;
    private YamlConfiguration topMenuConfig;
    private YamlConfiguration questMenuConfig;
    private final Map<UUID, String> openStorageMenu;
    // key: "clanName:menuType" or "global:menuType" for non-clan menus
    // value: UUID of player who has it open
    private final Map<String, UUID> menuLocks;

    public MenuManager(NovaClans plugin) {
        this.openStorageMenu = new HashMap<>();
        this.menuLocks = new HashMap<>();
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        File menuDir = new File(plugin.getDataFolder(), "menus");
        if (!menuDir.exists()) menuDir.mkdirs();

        File clanMenuFile = new File(menuDir, "clan_menu.yml");
        File storageMenuFile = new File(menuDir, "storage_menu.yml");
        File membersMenuFile = new File(menuDir, "members_menu.yml");
        File topMenuFile = new File(menuDir, "top_menu.yml");
        File questMenuFile = new File(menuDir, "quest_menu.yml");

        if (!clanMenuFile.exists()) plugin.saveResource("menus/clan_menu.yml", false);
        if (!storageMenuFile.exists()) plugin.saveResource("menus/storage_menu.yml", false);
        if (!membersMenuFile.exists()) plugin.saveResource("menus/members_menu.yml", false);
        if (!topMenuFile.exists()) plugin.saveResource("menus/top_menu.yml", false);
        if (!questMenuFile.exists()) plugin.saveResource("menus/quest_menu.yml", false);

        clanMenuConfig = YamlConfiguration.loadConfiguration(clanMenuFile);
        storageMenuConfig = YamlConfiguration.loadConfiguration(storageMenuFile);
        membersMenuConfig = YamlConfiguration.loadConfiguration(membersMenuFile);
        topMenuConfig = YamlConfiguration.loadConfiguration(topMenuFile);
        questMenuConfig = YamlConfiguration.loadConfiguration(questMenuFile);
    }

    public void openMainMenu(Player player) {
        boolean inClan = plugin.getDataManager().isInClan(player.getUniqueId());
        if (!inClan) {
            openNoClanMenu(player);
        } else {
            openClanMenu(player, plugin.getDataManager().getClanByPlayer(player.getUniqueId()));
        }
    }

    private void openNoClanMenu(Player player) {
        String lockKey = player.getUniqueId() + ":noclan";
        if (!acquireLock(player, lockKey)) return;
        ConfigurationSection cfg = clanMenuConfig.getConfigurationSection("no-clan-menu");
        if (cfg == null) return;
        int rows = cfg.getInt("rows", 3);
        String titleRaw = cfg.getString("title", "&7\u041a\u043b\u0430\u043d \u041c\u04d9\u0437\u0456\u0440\u0456");
        Component title = parseTitle(titleRaw);
        Inventory inv = Bukkit.createInventory((InventoryHolder) null, rows * 9, title);
        fillItems(inv, cfg, player, null);
        player.openInventory(inv);
    }

    private void openClanMenu(Player player, ClanData clan) {
        String lockKey = clanLockKey(clan, "main");
        if (!acquireLock(player, lockKey)) return;
        ConfigurationSection cfg = clanMenuConfig.getConfigurationSection("clan-menu");
        if (cfg == null) return;
        int rows = cfg.getInt("rows", 4);
        String titleRaw = applyPlaceholders(cfg.getString("title", "&7\u041a\u043b\u0430\u043d"), player, clan);
        Component title = parseTitle(titleRaw);
        Inventory inv = Bukkit.createInventory((InventoryHolder) null, rows * 9, title);
        fillItems(inv, cfg, player, clan);
        player.openInventory(inv);
    }

    private void fillItems(Inventory inv, ConfigurationSection cfg, Player player, ClanData clan) {
        ConfigurationSection items = cfg.getConfigurationSection("items");
        if (items == null) return;
        for (String key : items.getKeys(false)) {
            ConfigurationSection ic = items.getConfigurationSection(key);
            if (ic == null) continue;
            List<Integer> slots = resolveSlots(ic);
            if (slots.isEmpty()) continue;
            ItemStack item = buildItemFromSection(ic, player, clan);
            for (int slot : slots) {
                if (slot >= 0 && slot < inv.getSize()) {
                    inv.setItem(slot, item);
                }
            }
        }
    }

    private List<Integer> resolveSlots(ConfigurationSection ic) {
        List<Integer> result = new ArrayList<>();
        if (ic.isList("slots")) {
            for (int s : ic.getIntegerList("slots")) {
                result.add(s);
            }
        } else if (ic.contains("slot")) {
            result.add(ic.getInt("slot", 0));
        }
        return result;
    }

    public void openStorageInfoMenu(Player player) {
        ClanData clan = plugin.getDataManager().getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            plugin.getMessageManager().send((CommandSender) player, "not-in-clan");
            return;
        }
        String lockKey = clanLockKey(clan, "storage-info");
        if (!acquireLock(player, lockKey)) return;
        ConfigurationSection cfg = storageMenuConfig.getConfigurationSection("storage-menu");
        if (cfg == null) return;
        int rows = cfg.getInt("rows", 4);
        String titleRaw = applyPlaceholders(cfg.getString("title", "&7\u041a\u043b\u0430\u043d \u049a\u043e\u0439\u043c\u0430\u0441\u044b"), player, clan);
        Component title = parseTitle(titleRaw);
        Inventory inv = Bukkit.createInventory((InventoryHolder) null, rows * 9, title);
        fillItems(inv, cfg, player, clan);
        openStorageMenu.put(player.getUniqueId(), clan.getName() + ":info");
        player.openInventory(inv);
    }

    public void openClanVault(Player player) {
        ClanData clan = plugin.getDataManager().getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            plugin.getMessageManager().send((CommandSender) player, "not-in-clan");
            return;
        }
        openVaultForClan(player, clan);
    }

    public void openAdminVault(Player player, ClanData clan) {
        openVaultForClan(player, clan);
    }

    private void openVaultForClan(Player player, ClanData clan) {
        String lockKey = clanLockKey(clan, "vault");
        if (!acquireLock(player, lockKey)) return;
        int slots = plugin.getConfig().getInt("storage.level-" + clan.getLevel(), 27);
        String titleStr = "<dark_gray>[<#ffc800>\u041a\u043b\u0430\u043d \u049a\u043e\u0439\u043c\u0430\u0441\u044b<dark_gray>] <#ffc800>" + clan.getName() + " <gray>| <aqua>Lv." + clan.getLevel();
        Component title = MessageManager.parse(titleStr);
        Inventory inv = Bukkit.createInventory((InventoryHolder) null, slots, title);
        ItemStack[] contents = clan.getStorageContents();
        if (contents != null) {
            for (int i = 0; i < Math.min(contents.length, slots); i++) {
                if (contents[i] != null) inv.setItem(i, contents[i]);
            }
        }
        openStorageMenu.put(player.getUniqueId(), clan.getName() + ":vault");
        player.openInventory(inv);
    }

    public void saveVaultAndClose(Player player, Inventory inv) {
        String entry = openStorageMenu.remove(player.getUniqueId());
        releaseLock(player.getUniqueId());
        if (entry == null || !entry.endsWith(":vault")) return;
        String clanName = entry.replace(":vault", "");
        ClanData clan = plugin.getDataManager().getClan(clanName);
        if (clan == null) return;
        clan.setStorageContents(inv.getContents());
        plugin.getDataManager().save();
    }

    public boolean isInStorageVault(UUID uuid) {
        String e = openStorageMenu.get(uuid);
        return e != null && e.endsWith(":vault");
    }

    public boolean isInStorageInfo(UUID uuid) {
        String e = openStorageMenu.get(uuid);
        return e != null && e.endsWith(":info");
    }

    public void removeFromStorageTracking(UUID uuid) {
        openStorageMenu.remove(uuid);
        releaseLock(uuid);
    }

    // ─── Menu Lock helpers ───────────────────────────────────────────────────

    /**
     * Try to acquire a lock for the given lockKey on behalf of player.
     * Returns true if the lock was acquired (or already held by this player).
     * Returns false if another player holds it (sends them a denial message).
     */
    private boolean acquireLock(Player player, String lockKey) {
        UUID current = menuLocks.get(lockKey);
        if (current == null || current.equals(player.getUniqueId())) {
            menuLocks.put(lockKey, player.getUniqueId());
            return true;
        }
        plugin.getMessageManager().sendRaw(player,
                "&8[&e\u1d04\u029f\u1d00\u0274&8] &r<red>\u0411\u04b1\u043b \u043c\u04d9\u0437\u0456\u0440 \u049b\u0430\u0437\u0456\u0440 \u0431\u0430\u0441\u049b\u0430 \u043e\u0439\u044b\u043d\u0448\u044b\u0434\u0430 \u0430\u0448\u044b\u049b \u0442\u04b1\u0440.");
        return false;
    }

    private void releaseLock(UUID uuid) {
        menuLocks.values().removeIf(v -> v.equals(uuid));
    }

    private String clanLockKey(ClanData clan, String menuType) {
        return clan.getName() + ":" + menuType;
    }

    public void openMembersMenu(Player player) {
        ClanData clan = plugin.getDataManager().getClanByPlayer(player.getUniqueId());
        if (clan == null) return;
        String lockKey = clanLockKey(clan, "members");
        if (!acquireLock(player, lockKey)) return;
        ConfigurationSection cfg = membersMenuConfig.getConfigurationSection("members-menu");
        int size = (cfg != null) ? (cfg.getInt("rows", 6) * 9) : 54;
        String titleRaw = (cfg != null) ? applyPlaceholders(cfg.getString("title", "&8\u041c\u04af\u0448\u0435\u043b\u0435\u0440"), player, clan) : ("&8\u041c\u04af\u0448\u0435\u043b\u0435\u0440 \u2014 " + clan.getName());
        Component title = parseTitle(titleRaw);
        Inventory inv = Bukkit.createInventory((InventoryHolder) null, size, title);
        if (cfg != null) {
            fillItems(inv, cfg, player, clan);
        } else {
            inv.setItem(49, buildItem(Material.ARROW, "<gradient:#ffc800:#f2990a><bold> \u2190 \u041a\u0435\u0440\u0456</bold></gradient>", List.of(" ", " <#ffc800>\u041d\u0435\u0433\u0456\u0437\u0433\u0456 \u043c\u04d9\u0437\u0456\u0440\u0433\u0435 \u043e\u0440\u0430\u043b\u0443", " "), false));
        }
        int slot = 0;
        for (Map.Entry<UUID, ClanMember> entry : clan.getMembers().entrySet()) {
            if (slot >= 45) break;
            ClanMember member = entry.getValue();
            String roleColor = getRoleColorMM(member.getRole());
            String roleIcon = getRoleIcon(member.getRole());
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            ItemMeta meta = head.getItemMeta();
            if (meta instanceof SkullMeta skullMeta) {
                skullMeta.setOwningPlayer(Bukkit.getOfflinePlayer(entry.getKey()));
                meta = skullMeta;
            }
            meta.displayName(MessageManager.parse("<gradient:#ffc800:#f2990a><bold>" + roleIcon + " " + member.getName() + "</bold></gradient>"));
            boolean online = Bukkit.getPlayer(entry.getKey()) != null;
            meta.lore(List.of(
                    MessageManager.parse("<#ffc800>\u0420\u04e9\u043b: " + roleColor + member.getRole().getDisplayName()),
                    MessageManager.parse("<#ffc800>\u041e\u043d\u043b\u0430\u0439\u043d: " + (online ? "<green>\u0418\u04d9" : "<red>\u0416\u043e\u049b"))
            ));
            head.setItemMeta(meta);
            inv.setItem(slot++, head);
        }
        player.openInventory(inv);
    }

    public void openTopMenu(Player player) {
        String lockKey = "global:top";
        if (!acquireLock(player, lockKey)) return;
        List<ClanData> top = plugin.getDataManager().getTopClans(10);
        ConfigurationSection cfg = topMenuConfig.getConfigurationSection("top-menu");
        int size = (cfg != null) ? (cfg.getInt("rows", 6) * 9) : 54;
        String titleRaw = (cfg != null) ? cfg.getString("title", "&8\u041a\u043b\u0430\u043d \u0422\u043e\u043f-10") : "&8\u041a\u043b\u0430\u043d \u0422\u043e\u043f-10";
        Component title = parseTitle(titleRaw);
        Inventory inv = Bukkit.createInventory((InventoryHolder) null, size, title);
        if (cfg != null) {
            fillItems(inv, cfg, player, null);
        } else {
            inv.setItem(49, buildItem(Material.ARROW, "<gradient:#ffc800:#f2990a><bold> \u2190 \u041a\u0435\u0440\u0456</bold></gradient>", List.of(" ", " <#ffc800>\u041d\u0435\u0433\u0456\u0437\u0433\u0456 \u043c\u04d9\u0437\u0456\u0440\u0433\u0435 \u043e\u0440\u0430\u043b\u0443", " "), false));
        }
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 28, 31, 34};
        Material[] medals = {Material.GOLD_INGOT, Material.IRON_INGOT, Material.COPPER_INGOT,
                Material.EMERALD, Material.DIAMOND, Material.AMETHYST_SHARD,
                Material.LAPIS_LAZULI, Material.REDSTONE, Material.QUARTZ, Material.COAL};
        for (int i = 0; i < Math.min(top.size(), 10); i++) {
            ClanData clan = top.get(i);
            List<String> lore = List.of(
                    "<#ffc800>\u0414\u0435\u04a3\u0433\u0435\u0439: <#f0e173>" + clan.getLevel(),
                    "<#ffc800>\u04b0\u043f\u0430\u0439: <#f0e173>" + clan.getPoints(),
                    "<#ffc800>\u0411\u0430\u043b\u0430\u043d\u0441: <#f0e173>" + plugin.getClanManager().formatMoney(clan.getBalance()),
                    "<#ffc800>\u041c\u04af\u0448\u0435\u043b\u0435\u0440: <#f0e173>" + clan.getMemberCount()
            );
            ItemStack item = buildItem(medals[i], "<gradient:#ffc800:#f2990a><bold>#" + (i + 1) + " " + clan.getName() + "</bold></gradient>", lore, i < 3);
            if (i < slots.length) inv.setItem(slots[i], item);
        }
        player.openInventory(inv);
    }

    public void openQuestMenu(Player player) {
        ClanData clan = plugin.getDataManager().getClanByPlayer(player.getUniqueId());
        if (clan == null) {
            plugin.getMessageManager().send((CommandSender) player, "not-in-clan");
            return;
        }
        String lockKey = clanLockKey(clan, "quest");
        if (!acquireLock(player, lockKey)) return;
        ConfigurationSection cfg = questMenuConfig.getConfigurationSection("quest-menu");
        int size = (cfg != null) ? (cfg.getInt("rows", 4) * 9) : 36;
        String titleRaw = (cfg != null) ? applyPlaceholders(cfg.getString("title", "&8\u041a\u0432\u0435\u0441\u0442\u0442\u0435\u0440"), player, clan) : "&8\u041a\u0432\u0435\u0441\u0442\u0442\u0435\u0440";
        Component title = parseTitle(titleRaw);
        Inventory inv = Bukkit.createInventory((InventoryHolder) null, size, title);
        if (cfg != null) {
            fillItems(inv, cfg, player, clan);
        } else {
            inv.setItem(31, buildItem(Material.ARROW, "<gradient:#ffc800:#f2990a><bold> \u2190 \u041a\u0435\u0440\u0456</bold></gradient>", List.of(" ", " <#ffc800>\u041d\u0435\u0433\u0456\u0437\u0433\u0456 \u043c\u04d9\u0437\u0456\u0440\u0433\u0435 \u043e\u0440\u0430\u043b\u0443", " "), false));
        }
        int maxLevel = plugin.getConfig().getInt("max-level", 5);
        long currentPoints = clan.getPoints();
        int currentLevel = clan.getLevel();
        long nextRequired = (currentLevel < maxLevel) ? plugin.getConfig().getLong("levels." + (currentLevel + 1), 0L) : plugin.getConfig().getLong("levels." + maxLevel, 0L);
        long prevRequired = plugin.getConfig().getLong("levels." + currentLevel, 0L);
        String progressBar = buildProgressBar(currentPoints - prevRequired, nextRequired - prevRequired, 20);
        List<String> progressLore = new ArrayList<>();
        progressLore.add("<#ffc800>\u0414\u0435\u04a3\u0433\u0435\u0439: <#f0e173>" + currentLevel + " <#ffc800>/ <#f0e173>" + maxLevel);
        progressLore.add("<#ffc800>\u04b0\u043f\u0430\u0439: <#f0e173>" + currentPoints + " <#ffc800>/ <#f0e173>" + nextRequired);
        progressLore.add(progressBar);
        progressLore.add("<#ffc800>\u04b0\u043f\u0430\u0439 \u0436\u0438\u043d\u0430\u0443 \u0436\u043e\u043b\u0434\u0430\u0440\u044b:");
        progressLore.add("<#ffc800>\u2694 \u041e\u0439\u044b\u043d\u0448\u044b \u04e9\u043b\u0442\u0456\u0440\u0443: <#f0e173>+2 \u04b1\u043f\u0430\u0439");
        progressLore.add("<#ffc800>\u2620 \u041c\u043e\u0431 \u04e9\u043b\u0442\u0456\u0440\u0443: <#f0e173>+1 \u04b1\u043f\u0430\u0439");
        inv.setItem(13, buildItem(Material.EXPERIENCE_BOTTLE, "<gradient:#ffc800:#f2990a><bold>\u2726 \u041a\u043b\u0430\u043d \u041f\u0440\u043e\u0433\u0440\u0435\u0441\u0456</bold></gradient>", progressLore, false));
        int[] levelSlots = {19, 21, 23, 25, 27};
        for (int lv = 1; lv <= maxLevel; lv++) {
            long req = plugin.getConfig().getLong("levels." + lv, 0L);
            boolean achieved = currentLevel >= lv;
            Material mat = achieved ? Material.LIME_STAINED_GLASS_PANE : Material.RED_STAINED_GLASS_PANE;
            String status = achieved ? "<green>\u2714 \u0416\u0435\u0442\u0456\u043b\u0434\u0456" : "<red>\u2718 \u0416\u0435\u0442\u0456\u043b\u043c\u0435\u0434\u0456";
            if (lv - 1 < levelSlots.length) {
                inv.setItem(levelSlots[lv - 1], buildItem(mat, "<gradient:#ffc800:#f2990a><bold>\u2b50 \u0414\u0435\u04a3\u0433\u0435\u0439 " + lv + "</bold></gradient>",
                        List.of("<#ffc800>\u041a\u0435\u0440\u0435\u043a\u0442\u0456 \u04b1\u043f\u0430\u0439: <#f0e173>" + req, status), false));
            }
        }
        player.openInventory(inv);
    }

    private ItemStack buildItemFromSection(ConfigurationSection sec, Player player, ClanData clan) {
        Material mat = parseMaterial(sec.getString("material", "STONE"));
        String nameRaw = applyPlaceholders(sec.getString("name", ""), player, clan);
        List<String> loreRaw = sec.getStringList("lore").stream().map(l -> applyPlaceholders(l, player, clan)).toList();
        boolean enchanted = sec.getBoolean("enchanted", false);
        return buildItem(mat, nameRaw, loreRaw, enchanted);
    }

    private ItemStack buildItem(Material mat, String name, List<String> lore, boolean enchanted) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;
        if (name != null && !name.isEmpty()) {
            meta.displayName(MessageManager.parse(ensureItemNameStyle(name)));
        }
        if (lore != null && !lore.isEmpty()) {
            List<net.kyori.adventure.text.Component> loreComponents = lore.stream().map(line -> MessageManager.parse(ensureLoreStyle(line))).toList();
            meta.lore(loreComponents);
        }
        if (enchanted) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        item.setItemMeta(meta);
        return item;
    }

    private String ensureItemNameStyle(String name) {
        if (name.contains("<gradient") || name.contains("<bold") || name.contains("<#")) {
            return name;
        }
        String cleaned = name.replaceAll("&l", "").replaceAll("\u00a7l", "");
        return "<gradient:#ffc800:#f2990a><bold>" + cleaned + "</bold></gradient>";
    }

    private String ensureLoreStyle(String line) {
        if (line == null || line.isEmpty()) return (line != null) ? line : "";
        if (line.contains("<gradient") || line.contains("<#") || line.contains("\u00a7")) return line;
        String stripped = line.replaceAll("&[0-9a-fA-Fk-oK-OrR]", "");
        stripped = stripped.replaceAll("(:\\s*)([0-9,\\.\\u20b8%+]+)", "$1<#f0e173>$2<#ffc800>");
        stripped = stripped.replaceAll("(%[^%]+%)", "<#f0e173>$1<#ffc800>");
        return "<#ffc800>" + stripped;
    }

    private String buildProgressBar(long current, long max, int length) {
        if (max <= 0L) return "<green>" + "\u2588".repeat(length);
        double ratio = Math.min(1.0, current / (double) max);
        int filled = (int) (ratio * length);
        return "<green>" + "\u2588".repeat(filled) + "<dark_gray>" + "\u2588".repeat(length - filled) + " <gray>(" + String.format("%.1f", ratio * 100.0) + "%)";
    }

    private String applyPlaceholders(String text, Player player, ClanData clan) {
        if (text == null) return "";
        if (clan != null) {
            ClanRole role = clan.getMemberRole(player.getUniqueId());
            text = text.replace("%nova_clan_name%", clan.getName())
                    .replace("%nova_clan_level%", String.valueOf(clan.getLevel()))
                    .replace("%nova_clan_points%", String.valueOf(clan.getPoints()))
                    .replace("%nova_clan_balance%", plugin.getClanManager().formatMoney(clan.getBalance()))
                    .replace("%nova_clan_role%", (role != null) ? role.getDisplayName() : "\u0416\u043e\u049b");
        } else {
            text = text.replace("%nova_clan_name%", "\u0416\u043e\u049b")
                    .replace("%nova_clan_level%", "0")
                    .replace("%nova_clan_points%", "0")
                    .replace("%nova_clan_balance%", "0")
                    .replace("%nova_clan_role%", "\u0416\u043e\u049b");
        }
        return text;
    }

    public void handleSubMenuSlotClick(Player player, int slot, String title) {
        if (title.contains("\u041c\u04af\u0448\u0435\u043b\u0435\u0440")) {
            ConfigurationSection cfg = membersMenuConfig.getConfigurationSection("members-menu");
            if (cfg != null) handleClickInConfig(player, slot, cfg);
            return;
        }
        if (title.contains("\u0422\u043e\u043f-10") || title.contains("\u041a\u043b\u0430\u043d \u0422\u043e\u043f")) {
            ConfigurationSection cfg = topMenuConfig.getConfigurationSection("top-menu");
            if (cfg != null) handleClickInConfig(player, slot, cfg);
            return;
        }
        if (title.contains("\u041a\u0432\u0435\u0441\u0442\u0442\u0435\u0440")) {
            ConfigurationSection cfg = questMenuConfig.getConfigurationSection("quest-menu");
            if (cfg != null) handleClickInConfig(player, slot, cfg);
        }
    }

    private void handleClickInConfig(Player player, int slot, ConfigurationSection cfg) {
        ConfigurationSection items = cfg.getConfigurationSection("items");
        if (items == null) return;
        for (String key : items.getKeys(false)) {
            ConfigurationSection ic = items.getConfigurationSection(key);
            if (ic == null) continue;
            List<Integer> slots = resolveSlots(ic);
            String action = ic.getString("action", "NONE");
            if (!slots.contains(slot)) continue;
            executeAction(player, action);
        }
    }

    public void handleStorageInfoSlotClick(Player player, int slot) {
        ConfigurationSection cfg = storageMenuConfig.getConfigurationSection("storage-menu");
        if (cfg == null) return;
        ConfigurationSection items = cfg.getConfigurationSection("items");
        if (items == null) return;
        for (String key : items.getKeys(false)) {
            ConfigurationSection ic = items.getConfigurationSection(key);
            if (ic == null) continue;
            List<Integer> slots = resolveSlots(ic);
            if (!slots.contains(slot)) continue;
            String action = ic.getString("action", "NONE");
            executeAction(player, action);
        }
    }

    public void handleMainMenuSlotClick(Player player, int slot, String title) {
        boolean inClan = plugin.getDataManager().isInClan(player.getUniqueId());
        ConfigurationSection cfg = inClan ? clanMenuConfig.getConfigurationSection("clan-menu") : clanMenuConfig.getConfigurationSection("no-clan-menu");
        if (cfg == null) return;
        ConfigurationSection items = cfg.getConfigurationSection("items");
        if (items == null) return;
        for (String key : items.getKeys(false)) {
            ConfigurationSection ic = items.getConfigurationSection(key);
            if (ic == null) continue;
            List<Integer> slots = resolveSlots(ic);
            if (!slots.contains(slot)) continue;
            String action = ic.getString("action", "NONE");
            executeAction(player, action);
        }
    }

    private void executeAction(Player player, String action) {
        if (action == null) return;
        switch (action.toUpperCase()) {
            case "OPEN_STORAGE":
            case "OPEN_STORAGE_INFO":
                player.closeInventory();
                openStorageInfoMenu(player);
                break;
            case "OPEN_VAULT":
                player.closeInventory();
                openClanVault(player);
                break;
            case "OPEN_QUESTS":
                player.closeInventory();
                openQuestMenu(player);
                break;
            case "OPEN_TOP":
                player.closeInventory();
                openTopMenu(player);
                break;
            case "OPEN_MEMBERS":
                player.closeInventory();
                openMembersMenu(player);
                break;
            case "OPEN_MAIN":
            case "BACK":
                player.closeInventory();
                openMainMenu(player);
                break;
            case "OPEN_CREATE_CHAT":
                player.closeInventory();
                plugin.getMessageManager().sendRaw((CommandSender) player, "&8[&e\u1d04\u029f\u1d00\u0274&8] &r<#ffc800>\u041a\u043b\u0430\u043d \u0430\u0442\u044b\u043d \u0447\u0430\u0442\u049b\u0430 \u0442\u0435\u0440\u0456\u04a3\u0456\u0437 \u043d\u0435\u043c\u0435\u0441\u0435 <#f0e173>/clan create <\u0430\u0442>");
                break;
        }
    }

    private String getRoleColorMM(ClanRole role) {
        return switch (role) {
            case LEADER -> "<red>";
            case DEPUTY -> "<yellow>";
            case MEMBER -> "<gray>";
        };
    }

    private String getRoleIcon(ClanRole role) {
        return switch (role) {
            case LEADER -> "\u2605";
            case DEPUTY -> "\u2726";
            case MEMBER -> "\u2022";
        };
    }

    private Component parseTitle(String raw) {
        if (raw == null) return Component.empty();
        if (!raw.startsWith("&") && !raw.startsWith("<") && !raw.startsWith("\u00a7")) {
            raw = "&7" + raw;
        }
        return MessageManager.parse(raw);
    }

    private Material parseMaterial(String name) {
        if (name == null) return Material.STONE;
        try {
            return Material.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return Material.STONE;
        }
    }
}
