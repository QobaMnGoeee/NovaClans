package kz.hourlyrewards;

import kz.hourlyrewards.commands.FreeCommand;
import kz.hourlyrewards.commands.FreeRewardCommand;
import kz.hourlyrewards.gui.RewardsGUI;
import kz.hourlyrewards.listeners.GuiClickListener;
import kz.hourlyrewards.listeners.PlayerJoinListener;
import kz.hourlyrewards.listeners.PlayerMoveListener;
import kz.hourlyrewards.managers.PlayerDataManager;
import kz.hourlyrewards.managers.PlaytimeManager;
import kz.hourlyrewards.managers.TaskManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import kz.hourlyrewards.utils.ColorUtils;

public class HourlyRewards extends JavaPlugin {

    private static HourlyRewards instance;

    private PlayerDataManager playerDataManager;
    private TaskManager taskManager;
    private PlaytimeManager playtimeManager;
    private RewardsGUI rewardsGUI;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();
        reloadConfig();

        this.playerDataManager = new PlayerDataManager(this);
        this.taskManager = new TaskManager(this);
        this.playtimeManager = new PlaytimeManager(this);
        this.rewardsGUI = new RewardsGUI(this);

        getCommand("free").setExecutor(new FreeCommand(this));
        getCommand("freereward").setExecutor(new FreeRewardCommand(this));

        Bukkit.getPluginManager().registerEvents(new PlayerJoinListener(this), this);
        Bukkit.getPluginManager().registerEvents(new PlayerMoveListener(this), this);
        Bukkit.getPluginManager().registerEvents(new GuiClickListener(this), this);

        for (Player player : Bukkit.getOnlinePlayers()) {
            playerDataManager.loadPlayer(player.getUniqueId());
        }

        playtimeManager.start();

        getLogger().info("[HourlyRewards] Плагин іске қосылды! Нұсқасы: " + getDescription().getVersion());
        Bukkit.getConsoleSender().sendMessage(ColorUtils.color("§a[HourlyRewards] §fПлагин іске қосылды! Нұсқасы: " + getDescription().getVersion()));
    }

    @Override
    public void onDisable() {
        if (playtimeManager != null) {
            playtimeManager.stop();
        }

        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getOpenInventory() != null) {
                player.closeInventory();
            }
        }

        if (playerDataManager != null) {
            playerDataManager.saveAllSync();
        }

        getLogger().info("[HourlyRewards] Плагин сөндірілді, деректер сақталды.");
    }

    public static HourlyRewards getInstance() {
        return instance;
    }

    public PlayerDataManager getPlayerDataManager() {
        return playerDataManager;
    }

    public TaskManager getTaskManager() {
        return taskManager;
    }

    public PlaytimeManager getPlaytimeManager() {
        return playtimeManager;
    }

    public RewardsGUI getRewardsGUI() {
        return rewardsGUI;
    }
}
