package kz.hourlyrewards.models;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerData {

    private final UUID uuid;
    private long playtimeSeconds;
    private long lastLoginTime;
    private boolean afk;
    private long lastMoveTime;
    private final Map<Integer, TaskState> taskStates;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        this.playtimeSeconds = 0;
        this.lastLoginTime = System.currentTimeMillis();
        this.afk = false;
        this.lastMoveTime = System.currentTimeMillis();
        this.taskStates = new HashMap<>();
        for (int i = 1; i <= 10; i++) {
            taskStates.put(i, i == 1 ? TaskState.OPEN : TaskState.LOCKED);
        }
    }

    public UUID getUuid() {
        return uuid;
    }

    public long getPlaytimeSeconds() {
        return playtimeSeconds;
    }

    public void setPlaytimeSeconds(long playtimeSeconds) {
        this.playtimeSeconds = playtimeSeconds;
    }

    public void addPlaytimeSeconds(long seconds) {
        this.playtimeSeconds += seconds;
    }

    public long getLastLoginTime() {
        return lastLoginTime;
    }

    public void setLastLoginTime(long lastLoginTime) {
        this.lastLoginTime = lastLoginTime;
    }

    public boolean isAfk() {
        return afk;
    }

    public void setAfk(boolean afk) {
        this.afk = afk;
    }

    public long getLastMoveTime() {
        return lastMoveTime;
    }

    public void setLastMoveTime(long lastMoveTime) {
        this.lastMoveTime = lastMoveTime;
    }

    public Map<Integer, TaskState> getTaskStates() {
        return taskStates;
    }

    public TaskState getTaskState(int taskId) {
        return taskStates.getOrDefault(taskId, TaskState.LOCKED);
    }

    public void setTaskState(int taskId, TaskState state) {
        taskStates.put(taskId, state);
    }
}