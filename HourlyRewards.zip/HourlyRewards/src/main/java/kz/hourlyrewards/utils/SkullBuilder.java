package kz.hourlyrewards.utils;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.Base64;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class SkullBuilder {

    public static ItemStack createSkull(String base64Texture, String displayName, List<String> lore) {
        return createSkull(base64Texture, displayName, lore, false);
    }

    public static ItemStack createSkull(String base64Texture, String displayName, List<String> lore, boolean glow) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        if (meta == null) return skull;

        try {
            PlayerProfile profile = Bukkit.createProfile(UUID.randomUUID(), "HRTexture");
            profile.setProperty(new ProfileProperty("textures", base64Texture));
            meta.setPlayerProfile(profile);
        } catch (Exception e) {
            Bukkit.getLogger().warning("[HourlyRewards] Skull текстурасын орнату қатесі: " + e.getMessage());
        }

        meta.setDisplayName(ColorUtils.color(displayName));
        meta.setLore(lore.stream().map(ColorUtils::color).collect(Collectors.toList()));

        if (glow) {
            meta.addEnchant(Enchantment.LUCK, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }

        skull.setItemMeta(meta);
        return skull;
    }
}