package kz.hourlyrewards.commands;

import kz.hourlyrewards.HourlyRewards;
import kz.hourlyrewards.models.PlayerData;
import kz.hourlyrewards.models.TaskState;
import kz.hourlyrewards.utils.ColorUtils;
import kz.hourlyrewards.utils.TimeUtils;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FreeRewardCommand implements CommandExecutor {

    private final HourlyRewards plugin;

    public FreeRewardCommand(HourlyRewards plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("hourlyrewards.admin")) {
            sender.sendMessage(ColorUtils.color("§cСізде рұқсат жоқ!"));
            return true;
        }

        if (args.length == 0) {
            sendUsage(sender);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "reload" -> {
                plugin.reloadConfig();
                sender.sendMessage(ColorUtils.color("§a[HourlyRewards] §fconfig.yml қайта жүктелді!"));
            }
            case "reset" -> {
                if (args.length < 2) {
                    sender.sendMessage(ColorUtils.color("§cҮлгі: /freereward reset <ойыншы>"));
                    return true;
                }
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                PlayerData data;
                boolean wasLoaded = plugin.getPlayerDataManager().isLoaded(target.getUniqueId());
                if (wasLoaded) {
                    data = plugin.getPlayerDataManager().getPlayer(target.getUniqueId());
                } else {
                    data = plugin.getPlayerDataManager().loadPlayer(target.getUniqueId());
                }
                data.setPlaytimeSeconds(0);
                for (int i = 1; i <= 10; i++) {
                    data.setTaskState(i, i == 1 ? TaskState.OPEN : TaskState.LOCKED);
                }
                plugin.getPlayerDataManager().savePlayerSync(target.getUniqueId());
                sender.sendMessage(ColorUtils.color("§a[HourlyRewards] §f" + args[1] + " ойыншысының деректері тазаланды!"));
                Player online = target.getPlayer();
                if (online != null) {
                    plugin.getRewardsGUI().refresh(online);
                }
            }
            case "settime" -> {
                if (args.length < 3) {
                    sender.sendMessage(ColorUtils.color("§cҮлгі: /freereward settime <ойыншы> <секунд>"));
                    return true;
                }
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                long seconds;
                try {
                    seconds = Long.parseLong(args[2]);
                } catch (NumberFormatException e) {
                    sender.sendMessage(ColorUtils.color("§cСекунд саны дұрыс емес!"));
                    return true;
                }
                PlayerData data;
                if (plugin.getPlayerDataManager().isLoaded(target.getUniqueId())) {
                    data = plugin.getPlayerDataManager().getPlayer(target.getUniqueId());
                } else {
                    data = plugin.getPlayerDataManager().loadPlayer(target.getUniqueId());
                }
                data.setPlaytimeSeconds(seconds);
                plugin.getPlayerDataManager().savePlayerSync(target.getUniqueId());
                sender.sendMessage(ColorUtils.color("§a[HourlyRewards] §f" + args[1] + " ойыншысының уақыты " + seconds + " секунд болып орнатылды!"));
                Player online = target.getPlayer();
                if (online != null) {
                    plugin.getTaskManager().checkAndUpdate(online);
                    plugin.getRewardsGUI().refresh(online);
                }
            }
            case "settask" -> {
                if (args.length < 4) {
                    sender.sendMessage(ColorUtils.color("§cҮлгі: /freereward settask <ойыншы> <1-10> <LOCKED|OPEN|READY|CLAIMED>"));
                    return true;
                }
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                int taskId;
                try {
                    taskId = Integer.parseInt(args[2]);
                } catch (NumberFormatException e) {
                    sender.sendMessage(ColorUtils.color("§cТапсырма нөмірі дұрыс емес!"));
                    return true;
                }
                if (taskId < 1 || taskId > 10) {
                    sender.sendMessage(ColorUtils.color("§cТапсырма нөмірі 1-10 аралығында болуы керек!"));
                    return true;
                }
                TaskState state;
                try {
                    state = TaskState.valueOf(args[3].toUpperCase());
                } catch (IllegalArgumentException e) {
                    sender.sendMessage(ColorUtils.color("§cКүй дұрыс емес! LOCKED, OPEN, READY немен CLAIMED қолданыңыз."));
                    return true;
                }
                PlayerData data;
                if (plugin.getPlayerDataManager().isLoaded(target.getUniqueId())) {
                    data = plugin.getPlayerDataManager().getPlayer(target.getUniqueId());
                } else {
                    data = plugin.getPlayerDataManager().loadPlayer(target.getUniqueId());
                }
                data.setTaskState(taskId, state);
                plugin.getPlayerDataManager().savePlayerSync(target.getUniqueId());
                sender.sendMessage(ColorUtils.color("§a[HourlyRewards] §f" + args[1] + " ойыншысының " + taskId + "-тапсырмасы " + state.name() + " күйіне өзгертілді!"));
                Player online = target.getPlayer();
                if (online != null) {
                    plugin.getRewardsGUI().refresh(online);
                }
            }
            case "info" -> {
                if (args.length < 2) {
                    sender.sendMessage(ColorUtils.color("§cҮлгі: /freereward info <ойыншы>"));
                    return true;
                }
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                PlayerData data;
                if (plugin.getPlayerDataManager().isLoaded(target.getUniqueId())) {
                    data = plugin.getPlayerDataManager().getPlayer(target.getUniqueId());
                } else {
                    data = plugin.getPlayerDataManager().loadPlayer(target.getUniqueId());
                }
                sender.sendMessage(ColorUtils.color("§a§l=== " + args[1] + " туралы мәлімет ==="));
                sender.sendMessage(ColorUtils.color("§fОйнаған уақыт§7: §e" + TimeUtils.formatTime(data.getPlaytimeSeconds()) + " §8(" + data.getPlaytimeSeconds() + " секунд)"));
                sender.sendMessage(ColorUtils.color("§fAFK§7: §e" + (data.isAfk() ? "Иә" : "Жоқ")));
                for (int i = 1; i <= 10; i++) {
                    sender.sendMessage(ColorUtils.color("§7" + i + "-тапсырма§7: §f" + data.getTaskState(i).name()));
                }
            }
            default -> sendUsage(sender);
        }

        return true;
    }

    private void sendUsage(CommandSender sender) {
        sender.sendMessage(ColorUtils.color("§a§l=== HourlyRewards Әкімшілік командалар ==="));
        sender.sendMessage(ColorUtils.color("§f/freereward reload §7- config.yml қайта жүктеу"));
        sender.sendMessage(ColorUtils.color("§f/freereward reset <ойыншы> §7- Ойыншының деректерін тазалау"));
        sender.sendMessage(ColorUtils.color("§f/freereward settime <ойыншы> <секунд> §7- Уақытты орнату"));
        sender.sendMessage(ColorUtils.color("§f/freereward settask <ойыншы> <1-10> <КҮЙ> §7- Тапсырма күйін өзгерту"));
        sender.sendMessage(ColorUtils.color("§f/freereward info <ойыншы> §7- Ойыншы туралы мәлімет"));
    }
}
