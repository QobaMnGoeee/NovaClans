package kz.hourlyrewards.commands;

import kz.hourlyrewards.HourlyRewards;
import kz.hourlyrewards.utils.ColorUtils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FreeCommand implements CommandExecutor {

    private final HourlyRewards plugin;

    public FreeCommand(HourlyRewards plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ColorUtils.color("§cБұл команда тек ойыншылар үшін!"));
            return true;
        }

        if (!player.hasPermission("hourlyrewards.use")) {
            player.sendMessage(ColorUtils.color("§cСізде рұқсат жоқ!"));
            return true;
        }

        plugin.getRewardsGUI().open(player);
        return true;
    }
}