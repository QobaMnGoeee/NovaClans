package kz.hourlyrewards.listeners;

import kz.hourlyrewards.HourlyRewards;
import kz.hourlyrewards.models.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerJoinListener implements Listener {

    private final HourlyRewards plugin;

    public PlayerJoinListener(HourlyRewards plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getPlayerDataManager().loadPlayer(player.getUniqueId());
        data.setLastLoginTime(System.currentTimeMillis());
        data.setLastMoveTime(System.currentTimeMillis());
        data.setAfk(false);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (player.getOpenInventory() != null) {
            player.closeInventory();
        }
        plugin.getPlayerDataManager().unloadPlayer(player.getUniqueId());
    }
}