package kz.hourlyrewards.listeners;

import kz.hourlyrewards.HourlyRewards;
import kz.hourlyrewards.models.PlayerData;
import kz.hourlyrewards.models.TaskState;
import kz.hourlyrewards.utils.ColorUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GuiClickListener implements Listener {

    private final HourlyRewards plugin;
    private final Map<UUID, Long> lastClick = new HashMap<>();
    private static final long CLICK_COOLDOWN_MS = 500L;

    public GuiClickListener(HourlyRewards plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        String title = ColorUtils.color(plugin.getConfig().getString("gui.title", "§a§lСағаттық Сыйлықтар"));
        if (!event.getView().getTitle().equals(title)) return;

        event.setCancelled(true);

        int slot = event.getRawSlot();
        Integer taskId = null;
        for (int i = 1; i <= 10; i++) {
            if (plugin.getTaskManager().getSlot(i) == slot) {
                taskId = i;
                break;
            }
        }
        if (taskId == null) return;

        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        Long last = lastClick.get(uuid);
        if (last != null && (now - last) < CLICK_COOLDOWN_MS) {
            return;
        }
        lastClick.put(uuid, now);

        PlayerData data = plugin.getPlayerDataManager().getPlayer(uuid);
        if (data == null) return;

        TaskState state = data.getTaskState(taskId);

        switch (state) {
            case READY -> {
                plugin.getTaskManager().giveReward(player, taskId);
                plugin.getRewardsGUI().refresh(player);
            }
            case LOCKED -> {
                String msg = plugin.getConfig().getString("messages.task-locked", "%prefix%§cАлдымен алдыңғы тапсырманы орындаңыз!");
                msg = msg.replace("%prefix%", plugin.getConfig().getString("messages.prefix", ""));
                player.sendMessage(ColorUtils.color(msg));
            }
            case OPEN -> {
                String required = plugin.getTaskManager().getDisplayTime(taskId);
                String current = kz.hourlyrewards.utils.TimeUtils.formatTime(data.getPlaytimeSeconds());
                String msg = plugin.getConfig().getString("messages.not-ready", "%prefix%§eТапсырма орындалмаған! Уақытыңыз: §f{current}§e / §f{required}");
                msg = msg.replace("%prefix%", plugin.getConfig().getString("messages.prefix", ""))
                        .replace("{current}", current)
                        .replace("{required}", required);
                player.sendMessage(ColorUtils.color(msg));
            }
            case CLAIMED -> {
                String msg = plugin.getConfig().getString("messages.already-claimed", "%prefix%§cБұл сыйлықты алдыңыз!");
                msg = msg.replace("%prefix%", plugin.getConfig().getString("messages.prefix", ""));
                player.sendMessage(ColorUtils.color(msg));
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        String title = ColorUtils.color(plugin.getConfig().getString("gui.title", "§a§lСағаттық Сыйлықтар"));
        if (!event.getView().getTitle().equals(title)) return;
    }
}
