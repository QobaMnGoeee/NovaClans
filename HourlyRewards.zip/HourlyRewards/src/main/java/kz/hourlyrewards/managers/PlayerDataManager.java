package kz.hourlyrewards.managers;

import kz.hourlyrewards.HourlyRewards;
import kz.hourlyrewards.models.PlayerData;
import kz.hourlyrewards.models.TaskState;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerDataManager {

    private final HourlyRewards plugin;
    private final Map<UUID, PlayerData> dataCache = new HashMap<>();
    private final File playerDataDir;

    public PlayerDataManager(HourlyRewards plugin) {
        this.plugin = plugin;
        this.playerDataDir = new File(plugin.getDataFolder(), "playerdata");
        if (!playerDataDir.exists()) {
            playerDataDir.mkdirs();
        }
    }

    public PlayerData loadPlayer(UUID uuid) {
        if (dataCache.containsKey(uuid)) {
            return dataCache.get(uuid);
        }

        File file = new File(playerDataDir, uuid.toString() + ".yml");
        PlayerData data = new PlayerData(uuid);

        if (file.exists()) {
            YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
            data.setPlaytimeSeconds(config.getLong("playtime_seconds", 0));
            data.setLastLoginTime(config.getLong("last_login", System.currentTimeMillis()));
            data.setAfk(config.getBoolean("is_afk", false));
            data.setLastMoveTime(config.getLong("last_move_time", System.currentTimeMillis()));

            for (int i = 1; i <= 10; i++) {
                String stateStr = config.getString("tasks.task_" + i + ".state", i == 1 ? "OPEN" : "LOCKED");
                try {
                    data.setTaskState(i, TaskState.valueOf(stateStr));
                } catch (IllegalArgumentException e) {
                    data.setTaskState(i, i == 1 ? TaskState.OPEN : TaskState.LOCKED);
                }
            }
        }

        dataCache.put(uuid, data);
        return data;
    }

    public void savePlayer(UUID uuid) {
        PlayerData data = dataCache.get(uuid);
        if (data == null) return;

        new BukkitRunnable() {
            @Override
            public void run() {
                File file = new File(playerDataDir, uuid.toString() + ".yml");
                YamlConfiguration config = new YamlConfiguration();
                config.set("playtime_seconds", data.getPlaytimeSeconds());
                config.set("last_login", data.getLastLoginTime());
                config.set("is_afk", data.isAfk());
                config.set("last_move_time", data.getLastMoveTime());

                for (int i = 1; i <= 10; i++) {
                    config.set("tasks.task_" + i + ".state", data.getTaskState(i).name());
                }

                try {
                    config.save(file);
                } catch (IOException e) {
                    plugin.getLogger().severe("[HourlyRewards] Деректерді сақтау қатесі: " + e.getMessage());
                }
            }
        }.runTaskAsynchronously(plugin);
    }

    public void savePlayerSync(UUID uuid) {
        PlayerData data = dataCache.get(uuid);
        if (data == null) return;

        File file = new File(playerDataDir, uuid.toString() + ".yml");
        YamlConfiguration config = new YamlConfiguration();
        config.set("playtime_seconds", data.getPlaytimeSeconds());
        config.set("last_login", data.getLastLoginTime());
        config.set("is_afk", data.isAfk());
        config.set("last_move_time", data.getLastMoveTime());

        for (int i = 1; i <= 10; i++) {
            config.set("tasks.task_" + i + ".state", data.getTaskState(i).name());
        }

        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("[HourlyRewards] Деректерді сақтау қатесі: " + e.getMessage());
        }
    }

    public void saveAllSync() {
        for (UUID uuid : dataCache.keySet()) {
            savePlayerSync(uuid);
        }
    }

    public void unloadPlayer(UUID uuid) {
        savePlayer(uuid);
        dataCache.remove(uuid);
    }

    public PlayerData getPlayer(UUID uuid) {
        return dataCache.get(uuid);
    }

    public boolean isLoaded(UUID uuid) {
        return dataCache.containsKey(uuid);
    }

    public Map<UUID, PlayerData> getAllLoaded() {
        return dataCache;
    }
}