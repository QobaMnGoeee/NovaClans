package kz.hourlyrewards.managers;

import kz.hourlyrewards.HourlyRewards;
import kz.hourlyrewards.models.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class PlaytimeManager {

    private final HourlyRewards plugin;
    private BukkitTask playtimeTask;
    private BukkitTask afkCheckTask;

    public PlaytimeManager(HourlyRewards plugin) {
        this.plugin = plugin;
    }

    public void start() {
        long saveInterval = plugin.getConfig().getLong("settings.playtime-save-interval", 60) * 20L;
        long checkInterval = plugin.getConfig().getLong("settings.check-interval", 60) * 20L;

        playtimeTask = new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    PlayerData data = plugin.getPlayerDataManager().getPlayer(player.getUniqueId());
                    if (data == null) continue;
                    if (!data.isAfk()) {
                        data.addPlaytimeSeconds(60);
                    }
                    plugin.getTaskManager().checkAndUpdate(player);
                }
            }
        }.runTaskTimer(plugin, saveInterval, saveInterval);

        long afkTimeout = plugin.getConfig().getLong("settings.afk-timeout-seconds", 300) * 1000L;

        afkCheckTask = new BukkitRunnable() {
            @Override
            public void run() {
                long now = System.currentTimeMillis();
                for (Player player : Bukkit.getOnlinePlayers()) {
                    PlayerData data = plugin.getPlayerDataManager().getPlayer(player.getUniqueId());
                    if (data == null) continue;
                    boolean isAfk = (now - data.getLastMoveTime()) > afkTimeout;
                    data.setAfk(isAfk);
                }
            }
        }.runTaskTimer(plugin, 600L, 600L);
    }

    public void stop() {
        if (playtimeTask != null) playtimeTask.cancel();
        if (afkCheckTask != null) afkCheckTask.cancel();
    }
}