package kz.hourlyrewards.managers;

import kz.hourlyrewards.HourlyRewards;
import kz.hourlyrewards.models.PlayerData;
import kz.hourlyrewards.models.TaskState;
import kz.hourlyrewards.utils.ColorUtils;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class TaskManager {

    private final HourlyRewards plugin;

    public TaskManager(HourlyRewards plugin) {
        this.plugin = plugin;
    }

    public void checkAndUpdate(Player player) {
        PlayerData data = plugin.getPlayerDataManager().getPlayer(player.getUniqueId());
        if (data == null) return;

        for (int i = 1; i <= 10; i++) {
            TaskState current = data.getTaskState(i);
            if (current != TaskState.OPEN) continue;

            long required = getRequiredSeconds(i);
            if (data.getPlaytimeSeconds() >= required) {
                data.setTaskState(i, TaskState.READY);
                plugin.getPlayerDataManager().savePlayer(player.getUniqueId());
                notifyPlayer(player, i);
            }
        }
    }

    public void giveReward(Player player, int taskId) {
        PlayerData data = plugin.getPlayerDataManager().getPlayer(player.getUniqueId());
        if (data == null) return;

        String cmd = getRewardCommand(taskId);
        if (cmd == null || cmd.isEmpty()) {
            plugin.getLogger().warning("[HourlyRewards] ЕСКЕРТУ: команда орындалмады, task_" + taskId);
            return;
        }

        String finalCmd = cmd.replace("%player%", player.getName());
        try {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), finalCmd);
        } catch (Exception e) {
            plugin.getLogger().warning("[HourlyRewards] ЕСКЕРТУ: команда орындалмады: " + finalCmd);
        }

        data.setTaskState(taskId, TaskState.CLAIMED);

        if (taskId < 10) {
            TaskState nextState = data.getTaskState(taskId + 1);
            if (nextState == TaskState.LOCKED) {
                data.setTaskState(taskId + 1, TaskState.OPEN);
            }
        }

        plugin.getPlayerDataManager().savePlayer(player.getUniqueId());

        String prize = getPrizeDisplay(taskId);
        String msg = plugin.getConfig().getString("messages.reward-claimed", "§a✔ §f{prize} сыйлығы алынды!");
        msg = msg.replace("%prefix%", plugin.getConfig().getString("messages.prefix", ""))
                 .replace("{prize}", prize != null ? prize : "");
        player.sendMessage(ColorUtils.color(msg));

        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        player.spawnParticle(org.bukkit.Particle.HAPPY_VILLAGER, player.getLocation().add(0, 1, 0), 20, 0.5, 0.5, 0.5, 0);
    }

    private void notifyPlayer(Player player, int taskId) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        String msg = plugin.getConfig().getString("messages.task-ready", "%prefix%§a{task}-тапсырма орындалды! §6/free §fжазып алыңыз!");
        msg = msg.replace("%prefix%", prefix).replace("{task}", String.valueOf(taskId));
        player.sendMessage(ColorUtils.color(msg));
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 1.0f);
    }

    public long getRequiredSeconds(int taskId) {
        return plugin.getConfig().getLong("tasks.task-" + taskId + ".required-seconds", 0);
    }

    public String getRewardCommand(int taskId) {
        return plugin.getConfig().getString("tasks.task-" + taskId + ".reward-command", "");
    }

    public String getPrizeDisplay(int taskId) {
        return plugin.getConfig().getString("tasks.task-" + taskId + ".prize-display", "");
    }

    public String getDisplayTime(int taskId) {
        return plugin.getConfig().getString("tasks.task-" + taskId + ".display-time", "");
    }

    public int getSlot(int taskId) {
        return plugin.getConfig().getInt("tasks.task-" + taskId + ".slot", 20 + taskId - 1);
    }
}