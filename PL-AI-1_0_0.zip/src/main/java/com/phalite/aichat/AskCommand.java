package com.phalite.aichat;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AskCommand implements CommandExecutor {

    private final PhaLiteAi plugin;
    private final AiClient aiClient;

    public AskCommand(PhaLiteAi plugin) {
        this.plugin = plugin;
        this.aiClient = new AiClient(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command");
            return true;
        }

        Player player = (Player) sender;

        if (!player.hasPermission("phalite.ai.ask")) {
            player.sendMessage(GradientUtil.apply("Сізде phalite.ai.ask рұқсаты жоқ", "#8b48ee", "#3a1066"));
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(GradientUtil.apply("/ask <сұрақ>", "#8b48ee", "#3a1066"));
            return true;
        }

        String question = String.join(" ", args);

        player.sendMessage(GradientUtil.apply("PhaLite ойланып жатыр...", "#8b48ee", "#3a1066"));

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            String answer;
            try {
                answer = aiClient.ask(question);
            } catch (Exception e) {
                answer = "Қате орын алды: " + e.getMessage();
                plugin.getLogger().warning(e.getMessage());
            }

            int maxLen = plugin.getConfig().getInt("max-response-length", 200);
            if (answer != null && answer.length() > maxLen) {
                answer = answer.substring(0, maxLen).trim() + "...";
            }

            String finalAnswer = (answer == null || answer.isBlank())
                    ? "Жауап алынбады"
                    : answer.replace("\n", " ").trim();

            plugin.getServer().getScheduler().runTask(plugin, () -> {
                String prefix = GradientUtil.apply("[PL]: ", "#8b48ee", "#c9a6ff");
                player.sendMessage(prefix + "§f" + finalAnswer);
            });
        });

        return true;
    }
}
