package com.phalite.aichat;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class AiClient {

    private final PhaLiteAi plugin;
    private final String apiUrl;
    private final int timeoutMs;

    public AiClient(PhaLiteAi plugin) {
        this.plugin = plugin;
        this.apiUrl = plugin.getConfig().getString("api-url");
        this.timeoutMs = plugin.getConfig().getInt("request-timeout-ms", 10000);
    }

    public String ask(String question) throws Exception {
        String systemPrompt = plugin.getConfig().getString("system-prompt", "");
        String fullPrompt = systemPrompt + "\n\n" + question;

        JsonObject part = new JsonObject();
        part.addProperty("text", fullPrompt);

        JsonArray partsArray = new JsonArray();
        partsArray.add(part);

        JsonObject content = new JsonObject();
        content.add("parts", partsArray);

        JsonArray contentsArray = new JsonArray();
        contentsArray.add(content);

        JsonObject body = new JsonObject();
        body.add("contents", contentsArray);

        String responseJson = sendPost(apiUrl, body.toString());
        return extractText(responseJson);
    }

    private String sendPost(String urlStr, String jsonBody) throws IOException {
        URL url = URI.create(urlStr).toURL();
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json; utf-8");
        conn.setRequestProperty("Accept", "application/json");
        conn.setConnectTimeout(timeoutMs);
        conn.setReadTimeout(timeoutMs);
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = jsonBody.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }

        int status = conn.getResponseCode();
        InputStream is = (status >= 200 && status < 300)
                ? conn.getInputStream()
                : conn.getErrorStream();

        StringBuilder sb = new StringBuilder();
        try (Scanner scanner = new Scanner(is, StandardCharsets.UTF_8)) {
            while (scanner.hasNextLine()) {
                sb.append(scanner.nextLine());
            }
        }

        if (status < 200 || status >= 300) {
            throw new IOException("HTTP " + status + " " + sb);
        }

        return sb.toString();
    }

    private String extractText(String json) {
        try {
            JsonElement root = JsonParser.parseString(json);
            if (!root.isJsonObject()) return json.trim();

            JsonObject obj = root.getAsJsonObject();

            if (obj.has("candidates")) {
                JsonArray candidates = obj.getAsJsonArray("candidates");
                if (candidates.size() > 0) {
                    JsonObject candidate = candidates.get(0).getAsJsonObject();
                    if (candidate.has("content")) {
                        JsonObject content = candidate.getAsJsonObject("content");
                        if (content.has("parts")) {
                            JsonArray parts = content.getAsJsonArray("parts");
                            if (parts.size() > 0 && parts.get(0).getAsJsonObject().has("text")) {
                                return parts.get(0).getAsJsonObject().get("text").getAsString();
                            }
                        }
                    }
                }
            }

            for (String key : new String[]{"response", "text", "result", "answer", "message"}) {
                if (obj.has(key) && obj.get(key).isJsonPrimitive()) {
                    return obj.get(key).getAsString();
                }
            }

            return json.trim();
        } catch (Exception e) {
            return json.trim();
        }
    }
}
