package com.phalite.aichat;

import org.bukkit.plugin.java.JavaPlugin;

public class PhaLiteAi extends JavaPlugin {

    private static PhaLiteAi instance;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        reloadConfig();
        AskCommand askCommand = new AskCommand(this);
        getCommand("ask").setExecutor(askCommand);
        getLogger().info("PhaLiteAi-v1_0_0 enabled");
    }

    @Override
    public void onDisable() {
        getLogger().info("PhaLiteAi-v1_0_0 disabled");
    }

    public static PhaLiteAi getInstance() {
        return instance;
    }
}
