package com.phalite.aichat;

public class GradientUtil {

    public static String apply(String text, String fromHex, String toHex) {
        int len = text.length();
        if (len == 0) return "";

        int fr = Integer.parseInt(fromHex.substring(1, 3), 16);
        int fg = Integer.parseInt(fromHex.substring(3, 5), 16);
        int fb = Integer.parseInt(fromHex.substring(5, 7), 16);

        int tr = Integer.parseInt(toHex.substring(1, 3), 16);
        int tg = Integer.parseInt(toHex.substring(3, 5), 16);
        int tb = Integer.parseInt(toHex.substring(5, 7), 16);

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < len; i++) {
            char c = text.charAt(i);
            double ratio = len == 1 ? 0 : (double) i / (len - 1);

            int r = (int) (fr + ratio * (tr - fr));
            int g = (int) (fg + ratio * (tg - fg));
            int b = (int) (fb + ratio * (tb - fb));

            result.append(toMinecraftHex(r, g, b)).append(c);
        }

        return result.toString();
    }

    private static String toMinecraftHex(int r, int g, int b) {
        String hex = String.format("%02x%02x%02x", r, g, b);
        StringBuilder sb = new StringBuilder("§x");
        for (char c : hex.toCharArray()) {
            sb.append("§").append(c);
        }
        return sb.toString();
    }
}
