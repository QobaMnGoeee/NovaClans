package kz.qoba.NovaEvents.commands;

import kz.qoba.NovaEvents.NovaEvents;
import kz.qoba.NovaEvents.listeners.PlayerListener;
import kz.qoba.NovaEvents.utils.ColorUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;

public class EventsCommand implements CommandExecutor {
   private final NovaEvents plugin;

   public EventsCommand(NovaEvents plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         if (!player.hasPermission("NovaEvents.use")) {
            player.sendMessage(this.plugin.getConfigManager().getMessage("no-permission"));
            return true;
         } else {
            PlayerListener listener = (PlayerListener)HandlerList.getRegisteredListeners(this.plugin).stream().map((reg) -> reg.getListener()).filter((l) -> l instanceof PlayerListener).findFirst().orElse((Object)null);
            if (listener != null) {
               listener.openEventsGUI(player);
            }

            return true;
         }
      } else {
         sender.sendMessage(ColorUtil.colorize("&cТек ойыншылар үшін!"));
         return true;
      }
   }
}
